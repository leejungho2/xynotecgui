using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Graphics3D
{
    public class DoubleBufferPanel : Panel
    {
        public DoubleBufferPanel()
        {
            this.DoubleBuffered = true;
       }
    }
}
