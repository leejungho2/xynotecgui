using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Graphics3D
{
    public partial class Form1 : Form
    {
        float azimuth = -179;
        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.HighQuality;

            float a = panel1.Height / 4;
            float elevation = Convert.ToSingle(tbElevation.Text);

            if (rbPicture.Checked)
                DrawPicture(g, 1.5f * a, elevation, azimuth);
            else
                DrawCube(g, a, elevation, azimuth);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Interval = 50;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            azimuth += 2;
            if (azimuth >= 180)
                azimuth = -179;
            panel1.Invalidate();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DrawPicture(Graphics g, float side, float elevation, float azimuth)
        {
            Matrix3 m = Matrix3.AzimuthElevation(elevation, azimuth);
            Point3[] pts = new Point3[3];
            pts[0] = new Point3(0, -side, side, 1);
            pts[1] = new Point3(0, side, side, 1);
            pts[2] = new Point3(0, -side, -side, 1);

            PointF[] pta = new PointF[3];
            for (int i = 0; i < pts.Length; i++)
            {
                pts[i].TransformNormalize(m);
            }
            pta[0] = Point2D(new PointF(pts[0].X, pts[0].Y));
            pta[1] = Point2D(new PointF(pts[1].X, pts[1].Y));
            pta[2] = Point2D(new PointF(pts[2].X, pts[2].Y));

            Image myImage1 = new Bitmap("image01.gif");
            Image myImage2 = new Bitmap("image02.gif");

            if (azimuth > -180 && azimuth < 0)
            {
                g.DrawImage(myImage1, pta);
            }
            else if (azimuth >= 0 && azimuth < 180)
            {
                g.DrawImage(myImage2, pta);
            }
        }

        private void DrawCube(Graphics g, float side, float elevation, float azimuth)
        {
            Matrix3 m = Matrix3.AzimuthElevation(elevation, azimuth);
            Point3[] pts = new Point3[11];
            // Create the cube:
            pts[0] = new Point3(side, -side, -side, 1);
            pts[1] = new Point3(side, side, -side, 1);
            pts[2] = new Point3(-side, side, -side, 1);
            pts[3] = new Point3(-side, -side, -side, 1);
            pts[4] = new Point3(-side, -side, side, 1);
            pts[5] = new Point3(side, -side, side, 1);
            pts[6] = new Point3(side, side, side, 1);
            pts[7] = new Point3(-side, side, side, 1);
            // Create coordinate axes:
            pts[8] = new Point3(2 * side, -side, -side, 1);
            pts[9] = new Point3(-side, 2 * side, -side, 1);
            pts[10] = new Point3(-side, -side, 2 * side, 1);

            PointF[] pta = new PointF[4];
            for (int i = 0; i < pts.Length; i++)
            {
                pts[i].TransformNormalize(m);
            }

            int[] i0, i1;
            i0 = new int[4] { 1, 2, 7, 6 };
            i1 = new int[4] { 2, 3, 4, 7 };

            if (azimuth >= -180 && azimuth < -90)
            {
                i0 = new int[4] { 1, 2, 7, 6 };
                i1 = new int[4] { 2, 3, 4, 7 };
            }
            else if (azimuth >= -90 && azimuth < 0)
            {
                i0 = new int[4] { 3, 4, 5, 0 };
                i1 = new int[4] { 2, 3, 4, 7 };
            }
            else if (azimuth >= 0 && azimuth < 90)
            {
                i0 = new int[4] { 3, 4, 5, 0 };
                i1 = new int[4] { 0, 1, 6, 5 };
            }
            else if (azimuth >= 90 && azimuth <= 180)
            {
                i0 = new int[4] { 1, 2, 7, 6 };
                i1 = new int[4] { 0, 1, 6, 5 };
            }

            pta[0] = Point2D(new PointF(pts[i0[0]].X, pts[i0[0]].Y));
            pta[1] = Point2D(new PointF(pts[i0[1]].X, pts[i0[1]].Y));
            pta[2] = Point2D(new PointF(pts[i0[2]].X, pts[i0[2]].Y));
            pta[3] = Point2D(new PointF(pts[i0[3]].X, pts[i0[3]].Y));
            g.FillPolygon(Brushes.LightGray, pta);
            g.DrawPolygon(Pens.Black, pta);
            pta[0] = Point2D(new PointF(pts[i1[0]].X, pts[i1[0]].Y));
            pta[1] = Point2D(new PointF(pts[i1[1]].X, pts[i1[1]].Y));
            pta[2] = Point2D(new PointF(pts[i1[2]].X, pts[i1[2]].Y));
            pta[3] = Point2D(new PointF(pts[i1[3]].X, pts[i1[3]].Y));
            g.FillPolygon(Brushes.LightGray, pta);
            g.DrawPolygon(Pens.Black, pta);

            if (elevation >= 0)
            {
                pta[0] = Point2D(new PointF(pts[4].X, pts[4].Y));
                pta[1] = Point2D(new PointF(pts[5].X, pts[5].Y));
                pta[2] = Point2D(new PointF(pts[6].X, pts[6].Y));
                pta[3] = Point2D(new PointF(pts[7].X, pts[7].Y));
                g.FillPolygon(Brushes.LightGray, pta);
            }
            else if (elevation < 0)
            {
                pta[0] = Point2D(new PointF(pts[0].X, pts[0].Y));
                pta[1] = Point2D(new PointF(pts[1].X, pts[1].Y));
                pta[2] = Point2D(new PointF(pts[2].X, pts[2].Y));
                pta[3] = Point2D(new PointF(pts[3].X, pts[3].Y));
                g.FillPolygon(Brushes.LightGray, pta);
            }
            g.DrawPolygon(Pens.Black, pta);
        }

        private PointF Point2D(PointF pt)
        {
            PointF aPoint = new PointF();
            aPoint.X = panel1.Width / 2 + pt.X;
            aPoint.Y = panel1.Height / 2 - pt.Y;
            return aPoint;
        }
    }
}