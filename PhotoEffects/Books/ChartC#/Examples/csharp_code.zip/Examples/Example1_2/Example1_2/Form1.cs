using System;
using System.Drawing;
using System.Windows.Forms;

namespace Example1_2
{
    public partial class Form1 : Form
    {
        // Define the drawing area
        private Rectangle drawingRectangle;
        // Unit defined in world coordinate system:
        private float xMin = 4f;
        private float xMax = 6f;
        private float yMin = 3f;
        private float yMax = 6f;
        // Define offset in unit of pixel:
        private int offset = 30;

        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.BackColor = Color.White;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            // Calculate the location and size of the drawing area
            // within which we want to draw the graphics:
            Rectangle rect = ClientRectangle;
            drawingRectangle = new Rectangle(rect.Location, rect.Size);
            drawingRectangle.Inflate(-offset, -offset);
            //Draw ClientRectangle and drawingRectangle using Pen:
            g.DrawRectangle(Pens.Red, rect);
            g.DrawRectangle(Pens.Black, drawingRectangle);
            // Draw a line from point (3,2) to Point (6, 7)
            // using the Pen with a width of 3 pixels:
            Pen aPen = new Pen(Color.Green, 3);
            g.DrawLine(aPen, Point2D(new PointF(3, 2)),
                Point2D(new PointF(6, 7)));
            aPen.Dispose();
            g.Dispose();
        }

        private PointF Point2D(PointF ptf)
        {
            PointF aPoint = new PointF();
            aPoint.X = drawingRectangle.X + (ptf.X - xMin) *
                drawingRectangle.Width / (xMax - xMin);
            aPoint.Y = drawingRectangle.Bottom - (ptf.Y - yMin) *
                drawingRectangle.Height / (yMax - yMin);
            return aPoint;
        }
    }
}
