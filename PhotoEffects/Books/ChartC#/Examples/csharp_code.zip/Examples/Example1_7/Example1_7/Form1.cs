using System;
using System.Drawing;
using System.Windows.Forms;

namespace Example1_7
{
    public partial class Form1 : Form
    {
        ColorDialog cdl = new ColorDialog();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] colorNames = Enum.GetNames(typeof(KnownColor));
            listBox1.Items.AddRange(colorNames);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            KnownColor selectedColor = (KnownColor)Enum.Parse(typeof(KnownColor), 
                listBox1.Text);
	        panel1.BackColor = Color.FromKnownColor(selectedColor);
            ColorInfo();
       }

        private void button1_Click(object sender, EventArgs e)
        {
            cdl.ShowDialog();
            panel1.BackColor = cdl.Color;
            ColorInfo();
        }

        private void ColorInfo()
        {
            // Show color information on the labels:
            // Brightness info:
            lblBrightness.Text = "Brightness = " +
                panel1.BackColor.GetBrightness().ToString();
            lblHue.Text = "Hue = " + panel1.BackColor.GetHue().ToString();
            // HUE Info:
            lblSaturation.Text = "Saturation = " +
                panel1.BackColor.GetSaturation().ToString();
            // RGB Hex info:
            string strRGBHex = string.Format("0x{0:X8}", panel1.BackColor.ToArgb());
            strRGBHex = "RGB = #" + strRGBHex.Substring(strRGBHex.Length - 6, 6);
            lblRGBHex.Text = strRGBHex;
            // ARGB value info:
            string strRGBValue = "ARGB = [" + panel1.BackColor.A.ToString() + ", " +
                panel1.BackColor.R.ToString() + ", " +
                panel1.BackColor.G.ToString() + ", " +
                panel1.BackColor.B.ToString() + "]";
            lblRGBValue.Text = strRGBValue;
        }
    }
}