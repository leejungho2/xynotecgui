namespace Example2_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rbRotationFirst = new System.Windows.Forms.RadioButton();
            this.rbTranslationFirst = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnShow = new System.Windows.Forms.Button();
            this.tbRotaionAngle = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbTranslationY = new System.Windows.Forms.TextBox();
            this.tbTranslationX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.rbRotationFirst);
            this.groupBox1.Controls.Add(this.rbTranslationFirst);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnReset);
            this.groupBox1.Controls.Add(this.btnShow);
            this.groupBox1.Controls.Add(this.tbRotaionAngle);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbTranslationY);
            this.groupBox1.Controls.Add(this.tbTranslationX);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(120, 376);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Rotation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Translation";
            // 
            // rbRotationFirst
            // 
            this.rbRotationFirst.AutoSize = true;
            this.rbRotationFirst.Location = new System.Drawing.Point(16, 72);
            this.rbRotationFirst.Name = "rbRotationFirst";
            this.rbRotationFirst.Size = new System.Drawing.Size(87, 17);
            this.rbRotationFirst.TabIndex = 17;
            this.rbRotationFirst.TabStop = true;
            this.rbRotationFirst.Text = "Rotation First";
            this.rbRotationFirst.UseVisualStyleBackColor = true;
            // 
            // rbTranslationFirst
            // 
            this.rbTranslationFirst.AutoSize = true;
            this.rbTranslationFirst.Checked = true;
            this.rbTranslationFirst.Location = new System.Drawing.Point(16, 48);
            this.rbTranslationFirst.Name = "rbTranslationFirst";
            this.rbTranslationFirst.Size = new System.Drawing.Size(96, 17);
            this.rbTranslationFirst.TabIndex = 16;
            this.rbTranslationFirst.TabStop = true;
            this.rbTranslationFirst.Text = "Translation first";
            this.rbTranslationFirst.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Order";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(8, 328);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(104, 24);
            this.btnReset.TabIndex = 14;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnShow
            // 
            this.btnShow.Location = new System.Drawing.Point(8, 288);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(104, 24);
            this.btnShow.TabIndex = 13;
            this.btnShow.Text = "Show Results";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // tbRotaionAngle
            // 
            this.tbRotaionAngle.Location = new System.Drawing.Point(48, 248);
            this.tbRotaionAngle.Name = "tbRotaionAngle";
            this.tbRotaionAngle.Size = new System.Drawing.Size(56, 20);
            this.tbRotaionAngle.TabIndex = 12;
            this.tbRotaionAngle.Text = "0";
            this.tbRotaionAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "angle";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 4;
            this.label2.Tag = "Y";
            this.label2.Text = "dy";
            // 
            // tbTranslationY
            // 
            this.tbTranslationY.Location = new System.Drawing.Point(48, 160);
            this.tbTranslationY.Name = "tbTranslationY";
            this.tbTranslationY.Size = new System.Drawing.Size(56, 20);
            this.tbTranslationY.TabIndex = 3;
            this.tbTranslationY.Text = "0";
            this.tbTranslationY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTranslationX
            // 
            this.tbTranslationX.Location = new System.Drawing.Point(48, 136);
            this.tbTranslationX.Name = "tbTranslationX";
            this.tbTranslationX.Size = new System.Drawing.Size(56, 20);
            this.tbTranslationX.TabIndex = 2;
            this.tbTranslationX.Text = "0";
            this.tbTranslationX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "dx";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Location = new System.Drawing.Point(136, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 372);
            this.panel1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 387);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbTranslationY;
        private System.Windows.Forms.TextBox tbTranslationX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.TextBox tbRotaionAngle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.RadioButton rbTranslationFirst;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rbRotationFirst;
    }
}

