using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Example2_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.White;
            // Subscribing to a paint eventhandler to drawingPanel: 
            panel1.Paint += new PaintEventHandler(panel1Paint);
        }

        private void panel1Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            DrawAxes(g);
            ApplyTransformation(g);
        }

        private void ApplyTransformation(Graphics g)
        {
           // Create a new transform matrix:
            Matrix m = new Matrix();
            // Bring origin to the center:
            m.Translate(panel1.Width/2, panel1.Height/2);

            if (rbTranslationFirst.Checked)
            {
                // Translation:
                int dx = Convert.ToInt16(tbTranslationX.Text);
                int dy = - Convert.ToInt16(tbTranslationY.Text);
                m.Translate(dx, dy,MatrixOrder.Append);
                // Rotation:
                float angle = Convert.ToSingle(tbRotaionAngle.Text);
                m.RotateAt(angle, new PointF(panel1.Width/2, 
                    panel1.Height/2), MatrixOrder.Append);
            }
            else if (rbRotationFirst.Checked)
            {
                // Rotation:
                float angle = Convert.ToSingle(tbRotaionAngle.Text);
                m.RotateAt(angle, new PointF(panel1.Width/2, 
                    panel1.Height/2), MatrixOrder.Append);
                // Translation:
                int dx = Convert.ToInt16(tbTranslationX.Text);
                int dy = - Convert.ToInt16(tbTranslationY.Text);
                m.Translate(dx, dy, MatrixOrder.Append);
            }
            g.Transform = m;
            DrawHouse(g, Color.Black);
        }

        private void DrawHouse(Graphics g, Color color)
        {
            HatchBrush hb = new HatchBrush(HatchStyle.HorizontalBrick,
                                color, Color.White);
            Pen aPen = new Pen(color, 2);
            Point[] pta = new Point[5];
            pta[0] = new Point(-40, 40);
            pta[1] = new Point(40, 40);
            pta[2] = new Point(40, -40);
            pta[3] = new Point(0, -80);
            pta[4] = new Point(-40, -40);
            g.FillPolygon(hb, pta);
            g.DrawPolygon(aPen, pta);
            hb.Dispose();
            aPen.Dispose();
        }
           
        private void DrawAxes(Graphics g)
        {
            Matrix m = new Matrix();
            // Move the origin to center of panel1:
            m.Translate(panel1.Width/2, panel1.Height/2);
            // Apply the transformation
            g.Transform = m;

            // Draw x and y axes:
            g.DrawLine(Pens.Blue, -panel1.Width / 2, 0, 
                panel1.Width / 2, 0);
            g.DrawLine(Pens.Blue, 0, -panel1.Height / 2, 0, 
                panel1.Height / 2);
            g.DrawString("X", this.Font, Brushes.Blue, 
                panel1.Width / 2 - 20, -20);
            g.DrawString("Y", this.Font, Brushes.Blue, 5, 
                -panel1.Height / 2+5);

            // Draw Ticks:
            int tick = 40;
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Far;
            for (int i = -160; i <= 160; i += tick)
            {
                g.DrawLine(Pens.Blue, i, -3, i, 3);
                g.DrawLine(Pens.Blue, -3, i, 3, i);

                SizeF sizeXTick = g.MeasureString(i.ToString(), 
                    this.Font);
                if (i != 0)
                {
                    g.DrawString(i.ToString(), this.Font, 
                        Brushes.Blue,
                        i + sizeXTick.Width / 2, 4f, sf);
                    g.DrawString((-i).ToString(), this.Font, 
                        Brushes.Blue,
                        -3f, i - sizeXTick.Height / 2, sf);
                }
                else
                {
                    g.DrawString("0", this.Font, Brushes.Blue,
                        new PointF(i - sizeXTick.Width / 3, 4f), sf);
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            // Reset parameters to default values:
            tbTranslationX.Text = "0";
            tbTranslationY.Text = "0";
            tbRotaionAngle.Text = "0";
            panel1.Invalidate();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            panel1.Invalidate();
        }
    }   
}