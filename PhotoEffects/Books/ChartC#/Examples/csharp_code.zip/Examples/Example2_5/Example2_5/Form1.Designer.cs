namespace Example2_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbGreenRotationAngle = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tbGreenTranslationY = new System.Windows.Forms.TextBox();
            this.tbGreenTranslationX = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbDBrickHouse = new System.Windows.Forms.CheckBox();
            this.cbHBrickHouse = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnShow = new System.Windows.Forms.Button();
            this.tbRedRotaionAngle = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbRedTranslationY = new System.Windows.Forms.TextBox();
            this.tbRedTranslationX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbGreenRotationAngle);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.tbGreenTranslationY);
            this.groupBox1.Controls.Add(this.tbGreenTranslationX);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.cbDBrickHouse);
            this.groupBox1.Controls.Add(this.cbHBrickHouse);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnReset);
            this.groupBox1.Controls.Add(this.btnShow);
            this.groupBox1.Controls.Add(this.tbRedRotaionAngle);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbRedTranslationY);
            this.groupBox1.Controls.Add(this.tbRedTranslationX);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(120, 376);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Rotation";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 228);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Translation";
            // 
            // tbGreenRotationAngle
            // 
            this.tbGreenRotationAngle.Location = new System.Drawing.Point(56, 200);
            this.tbGreenRotationAngle.Name = "tbGreenRotationAngle";
            this.tbGreenRotationAngle.Size = new System.Drawing.Size(56, 20);
            this.tbGreenRotationAngle.TabIndex = 27;
            this.tbGreenRotationAngle.Text = "0";
            this.tbGreenRotationAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 204);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "angle";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 272);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 13);
            this.label10.TabIndex = 25;
            this.label10.Tag = "Y";
            this.label10.Text = "dy";
            // 
            // tbGreenTranslationY
            // 
            this.tbGreenTranslationY.Location = new System.Drawing.Point(56, 268);
            this.tbGreenTranslationY.Name = "tbGreenTranslationY";
            this.tbGreenTranslationY.Size = new System.Drawing.Size(56, 20);
            this.tbGreenTranslationY.TabIndex = 24;
            this.tbGreenTranslationY.Text = "0";
            this.tbGreenTranslationY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbGreenTranslationX
            // 
            this.tbGreenTranslationX.Location = new System.Drawing.Point(56, 244);
            this.tbGreenTranslationX.Name = "tbGreenTranslationX";
            this.tbGreenTranslationX.Size = new System.Drawing.Size(56, 20);
            this.tbGreenTranslationX.TabIndex = 23;
            this.tbGreenTranslationX.Text = "-100";
            this.tbGreenTranslationX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 248);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "dx";
            // 
            // cbDBrickHouse
            // 
            this.cbDBrickHouse.AutoSize = true;
            this.cbDBrickHouse.Checked = true;
            this.cbDBrickHouse.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbDBrickHouse.Location = new System.Drawing.Point(8, 156);
            this.cbDBrickHouse.Name = "cbDBrickHouse";
            this.cbDBrickHouse.Size = new System.Drawing.Size(92, 17);
            this.cbDBrickHouse.TabIndex = 21;
            this.cbDBrickHouse.Text = "DBrick House";
            this.cbDBrickHouse.UseVisualStyleBackColor = true;
            // 
            // cbHBrickHouse
            // 
            this.cbHBrickHouse.AutoSize = true;
            this.cbHBrickHouse.Checked = true;
            this.cbHBrickHouse.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbHBrickHouse.Location = new System.Drawing.Point(8, 16);
            this.cbHBrickHouse.Name = "cbHBrickHouse";
            this.cbHBrickHouse.Size = new System.Drawing.Size(92, 17);
            this.cbHBrickHouse.TabIndex = 20;
            this.cbHBrickHouse.Text = "HBrick House";
            this.cbHBrickHouse.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Rotation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Translation";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 15;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(8, 344);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(104, 24);
            this.btnReset.TabIndex = 14;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnShow
            // 
            this.btnShow.Location = new System.Drawing.Point(8, 312);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(104, 24);
            this.btnShow.TabIndex = 13;
            this.btnShow.Text = "Show Results";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // tbRedRotaionAngle
            // 
            this.tbRedRotaionAngle.Location = new System.Drawing.Point(56, 124);
            this.tbRedRotaionAngle.Name = "tbRedRotaionAngle";
            this.tbRedRotaionAngle.Size = new System.Drawing.Size(56, 20);
            this.tbRedRotaionAngle.TabIndex = 12;
            this.tbRedRotaionAngle.Text = "0";
            this.tbRedRotaionAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "angle";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 4;
            this.label2.Tag = "Y";
            this.label2.Text = "dy";
            // 
            // tbRedTranslationY
            // 
            this.tbRedTranslationY.Location = new System.Drawing.Point(56, 80);
            this.tbRedTranslationY.Name = "tbRedTranslationY";
            this.tbRedTranslationY.Size = new System.Drawing.Size(56, 20);
            this.tbRedTranslationY.TabIndex = 3;
            this.tbRedTranslationY.Text = "0";
            this.tbRedTranslationY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRedTranslationX
            // 
            this.tbRedTranslationX.Location = new System.Drawing.Point(56, 56);
            this.tbRedTranslationX.Name = "tbRedTranslationX";
            this.tbRedTranslationX.Size = new System.Drawing.Size(56, 20);
            this.tbRedTranslationX.TabIndex = 2;
            this.tbRedTranslationX.Text = "100";
            this.tbRedTranslationX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "dx";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Location = new System.Drawing.Point(136, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 372);
            this.panel1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 387);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbRedTranslationY;
        private System.Windows.Forms.TextBox tbRedTranslationX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.TextBox tbRedRotaionAngle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cbDBrickHouse;
        private System.Windows.Forms.CheckBox cbHBrickHouse;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbGreenRotationAngle;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbGreenTranslationY;
        private System.Windows.Forms.TextBox tbGreenTranslationX;
        private System.Windows.Forms.Label label11;
    }
}

