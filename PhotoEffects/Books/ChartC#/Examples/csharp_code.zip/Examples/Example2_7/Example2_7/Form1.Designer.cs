namespace Example2_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbShearY = new System.Windows.Forms.TextBox();
            this.tbShearX = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rbShear = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.tbRotateAtY = new System.Windows.Forms.TextBox();
            this.tbRotateAtX = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnShow = new System.Windows.Forms.Button();
            this.tbRotaionAngle = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rbRotation = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.tbScaleY = new System.Windows.Forms.TextBox();
            this.tbScaleX = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rbScale = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.tbTranslationY = new System.Windows.Forms.TextBox();
            this.tbTranslationX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rbTranslation = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbShearY);
            this.groupBox1.Controls.Add(this.tbShearX);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.rbShear);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbRotateAtY);
            this.groupBox1.Controls.Add(this.tbRotateAtX);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.btnReset);
            this.groupBox1.Controls.Add(this.btnShow);
            this.groupBox1.Controls.Add(this.tbRotaionAngle);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.rbRotation);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbScaleY);
            this.groupBox1.Controls.Add(this.tbScaleX);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.rbScale);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbTranslationY);
            this.groupBox1.Controls.Add(this.tbTranslationX);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.rbTranslation);
            this.groupBox1.Location = new System.Drawing.Point(8, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(120, 432);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 23;
            this.label8.Tag = "Y";
            this.label8.Text = "Y";
            // 
            // tbShearY
            // 
            this.tbShearY.Location = new System.Drawing.Point(56, 312);
            this.tbShearY.Name = "tbShearY";
            this.tbShearY.Size = new System.Drawing.Size(56, 20);
            this.tbShearY.TabIndex = 22;
            this.tbShearY.Text = "0";
            this.tbShearY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbShearX
            // 
            this.tbShearX.Location = new System.Drawing.Point(56, 288);
            this.tbShearX.Name = "tbShearX";
            this.tbShearX.Size = new System.Drawing.Size(56, 20);
            this.tbShearX.TabIndex = 21;
            this.tbShearX.Text = "0";
            this.tbShearX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 296);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "X";
            // 
            // rbShear
            // 
            this.rbShear.AutoSize = true;
            this.rbShear.Location = new System.Drawing.Point(8, 268);
            this.rbShear.Name = "rbShear";
            this.rbShear.Size = new System.Drawing.Size(53, 17);
            this.rbShear.TabIndex = 19;
            this.rbShear.TabStop = true;
            this.rbShear.Text = "Shear";
            this.rbShear.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 18;
            this.label6.Tag = "Y";
            this.label6.Text = "Y";
            // 
            // tbRotateAtY
            // 
            this.tbRotateAtY.Location = new System.Drawing.Point(56, 236);
            this.tbRotateAtY.Name = "tbRotateAtY";
            this.tbRotateAtY.Size = new System.Drawing.Size(56, 20);
            this.tbRotateAtY.TabIndex = 17;
            this.tbRotateAtY.Text = "0";
            this.tbRotateAtY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRotateAtX
            // 
            this.tbRotateAtX.Location = new System.Drawing.Point(56, 212);
            this.tbRotateAtX.Name = "tbRotateAtX";
            this.tbRotateAtX.Size = new System.Drawing.Size(56, 20);
            this.tbRotateAtX.TabIndex = 16;
            this.tbRotateAtX.Text = "0";
            this.tbRotateAtX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(32, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "X";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(8, 392);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(104, 24);
            this.btnReset.TabIndex = 14;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnShow
            // 
            this.btnShow.Location = new System.Drawing.Point(8, 360);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(104, 24);
            this.btnShow.TabIndex = 13;
            this.btnShow.Text = "Show Results";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // tbRotaionAngle
            // 
            this.tbRotaionAngle.Location = new System.Drawing.Point(56, 184);
            this.tbRotaionAngle.Name = "tbRotaionAngle";
            this.tbRotaionAngle.Size = new System.Drawing.Size(56, 20);
            this.tbRotaionAngle.TabIndex = 12;
            this.tbRotaionAngle.Text = "0";
            this.tbRotaionAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Angle";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rbRotation
            // 
            this.rbRotation.AutoSize = true;
            this.rbRotation.Location = new System.Drawing.Point(8, 164);
            this.rbRotation.Name = "rbRotation";
            this.rbRotation.Size = new System.Drawing.Size(65, 17);
            this.rbRotation.TabIndex = 10;
            this.rbRotation.TabStop = true;
            this.rbRotation.Text = "Rotation";
            this.rbRotation.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 9;
            this.label3.Tag = "Y";
            this.label3.Text = "Y";
            // 
            // tbScaleY
            // 
            this.tbScaleY.Location = new System.Drawing.Point(56, 136);
            this.tbScaleY.Name = "tbScaleY";
            this.tbScaleY.Size = new System.Drawing.Size(56, 20);
            this.tbScaleY.TabIndex = 8;
            this.tbScaleY.Text = "1";
            this.tbScaleY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbScaleX
            // 
            this.tbScaleX.Location = new System.Drawing.Point(56, 112);
            this.tbScaleX.Name = "tbScaleX";
            this.tbScaleX.Size = new System.Drawing.Size(56, 20);
            this.tbScaleX.TabIndex = 7;
            this.tbScaleX.Text = "1";
            this.tbScaleX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "X";
            // 
            // rbScale
            // 
            this.rbScale.AutoSize = true;
            this.rbScale.Location = new System.Drawing.Point(8, 92);
            this.rbScale.Name = "rbScale";
            this.rbScale.Size = new System.Drawing.Size(52, 17);
            this.rbScale.TabIndex = 5;
            this.rbScale.TabStop = true;
            this.rbScale.Text = "Scale";
            this.rbScale.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 4;
            this.label2.Tag = "Y";
            this.label2.Text = "Y";
            // 
            // tbTranslationY
            // 
            this.tbTranslationY.Location = new System.Drawing.Point(56, 64);
            this.tbTranslationY.Name = "tbTranslationY";
            this.tbTranslationY.Size = new System.Drawing.Size(56, 20);
            this.tbTranslationY.TabIndex = 3;
            this.tbTranslationY.Text = "0";
            this.tbTranslationY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTranslationX
            // 
            this.tbTranslationX.Location = new System.Drawing.Point(56, 40);
            this.tbTranslationX.Name = "tbTranslationX";
            this.tbTranslationX.Size = new System.Drawing.Size(56, 20);
            this.tbTranslationX.TabIndex = 2;
            this.tbTranslationX.Text = "0";
            this.tbTranslationX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "X";
            // 
            // rbTranslation
            // 
            this.rbTranslation.AutoSize = true;
            this.rbTranslation.Location = new System.Drawing.Point(8, 16);
            this.rbTranslation.Name = "rbTranslation";
            this.rbTranslation.Size = new System.Drawing.Size(77, 17);
            this.rbTranslation.TabIndex = 0;
            this.rbTranslation.TabStop = true;
            this.rbTranslation.Text = "Translation";
            this.rbTranslation.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Location = new System.Drawing.Point(136, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(437, 427);
            this.panel1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 442);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbTranslationY;
        private System.Windows.Forms.TextBox tbTranslationX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbTranslation;
        private System.Windows.Forms.RadioButton rbScale;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbRotation;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbScaleY;
        private System.Windows.Forms.TextBox tbScaleX;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.TextBox tbRotaionAngle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbRotateAtY;
        private System.Windows.Forms.TextBox tbRotateAtX;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbShearY;
        private System.Windows.Forms.TextBox tbShearX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rbShear;
    }
}

