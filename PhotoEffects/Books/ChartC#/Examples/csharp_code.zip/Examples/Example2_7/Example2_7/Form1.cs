using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Example2_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.White;
            // Subscribing to a paint eventhandler to drawingPanel: 
            panel1.Paint += new PaintEventHandler(panel1Paint);
        }

        private void panel1Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            DrawAxes(g);
            ApplyTransformation(g);
        }

        private void ApplyTransformation(Graphics g)
        {
           // Reset graphics matrix to identity matrx:
            g.ResetTransform();
            // Bring origin to the center of the panel1:
            g.TranslateTransform(panel1.Width / 2, panel1.Height / 2);

            if (rbTranslation.Checked)
            {
                // Translation:
                int dx = Convert.ToInt16(tbTranslationX.Text);
                int dy = - Convert.ToInt16(tbTranslationY.Text);
                g.TranslateTransform(dx, dy);
            }
            else if (rbScale.Checked)
            {
                // Scaling:
                float sx = Convert.ToSingle(tbScaleX.Text);
                float sy = Convert.ToSingle(tbScaleY.Text);
                g.ScaleTransform(sy, sy);
            }
            else if (rbRotation.Checked)
            {
                // Rotation:
                float angle = Convert.ToSingle(tbRotaionAngle.Text);
                float x =  Convert.ToSingle(tbRotateAtX.Text);
                float y =  - Convert.ToSingle(tbRotateAtY.Text);
                g.FillEllipse(Brushes.Black, x - 4, y - 4, 8, 8);
                g.RotateTransform(angle);
            }
            else if (rbShear.Checked)
            {
                // Shear:
                Matrix m = new Matrix();
                float alpha = Convert.ToSingle(tbShearX.Text);
                float beta = Convert.ToSingle(tbShearY.Text);
                m.Shear(alpha, beta);
                g.MultiplyTransform(m);
            }
            DrawHouse(g, Color.Black);
        }

        private void DrawHouse(Graphics g, Color color)
        {
            HatchBrush hb = new HatchBrush(HatchStyle.HorizontalBrick, color, Color.White);
            Pen aPen = new Pen(color, 2);
            Point[] pta = new Point[5];
            pta[0] = new Point(-40, 40);
            pta[1] = new Point(40, 40);
            pta[2] = new Point(40, -40);
            pta[3] = new Point(0, -80);
            pta[4] = new Point(-40, -40);
            g.FillPolygon(hb, pta);
            g.DrawPolygon(aPen, pta);
            aPen.Dispose();
            hb.Dispose();
        }           

        private void DrawAxes(Graphics g)
        {

            // Move the origin to center of panel1:
            //m.Translate(panel1.Width/2, panel1.Height/2);
            g.ResetTransform();
            g.TranslateTransform(panel1.Width / 2, panel1.Height / 2);

            // Draw x and y axes:
            g.DrawLine(Pens.Blue, -panel1.Width / 2, 0, panel1.Width / 2, 0);
            g.DrawLine(Pens.Blue, 0, -panel1.Height / 2, 0, panel1.Height / 2);
            g.DrawString("X", this.Font, Brushes.Blue, panel1.Width / 2 - 20, -20);
            g.DrawString("Y", this.Font, Brushes.Blue, 5, -panel1.Height / 2+5);

            // Draw Ticks:
            int tick = 40;
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Far;
            for (int i = -200; i <= 200; i += tick)
            {
                g.DrawLine(Pens.Blue, i, -3, i, 3);
                g.DrawLine(Pens.Blue, -3, i, 3, i);

                SizeF sizeXTick = g.MeasureString(i.ToString(), this.Font);
                if (i != 0)
                {
                    g.DrawString(i.ToString(), this.Font, Brushes.Blue,
                        i + sizeXTick.Width / 2, 4f, sf);
                    g.DrawString((-i).ToString(), this.Font, Brushes.Blue,
                        -3f, i - sizeXTick.Height / 2, sf);

                }
                else
                {
                    g.DrawString("0", this.Font, Brushes.Blue,
                        new PointF(i - sizeXTick.Width / 3, 4f), sf);
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            // Reset parameters to default values:
            tbTranslationX.Text = "0";
            tbTranslationY.Text = "0";
            tbScaleX.Text = "1";
            tbScaleY.Text = "1";
            tbRotaionAngle.Text = "0";
            tbRotateAtX.Text = "0";
            tbRotateAtY.Text = "0";
            tbShearX.Text = "0";
            tbShearY.Text = "0";
            panel1.Invalidate();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            panel1.Invalidate();
        }

    }   
}