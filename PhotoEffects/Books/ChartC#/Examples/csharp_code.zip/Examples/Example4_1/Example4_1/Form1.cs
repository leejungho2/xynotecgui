using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Example4_1
{
    public partial class Form1 : Form
    {
        private ChartStyle cs;
        private DataCollection dc;
        private DataSeries ds;

        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.BackColor = Color.White;

            // Subscribing to a paint eventhandler to drawingPanel: 
            PlotPanel.Paint +=
                new PaintEventHandler(PlotPanelPaint);

            cs = new ChartStyle(this);
            dc = new DataCollection();
            // Specify chart style parameters:
            cs.Title = "Bar Chart";

            cs.XLimMin = 0f;
            cs.XLimMax = 25f;
            cs.YLimMin = 0f;
            cs.YLimMax = 5f;
            cs.XTick = 5f;
            cs.YTick = 1f;
            cs.BarType = ChartStyle.BarTypeEnum.HorizontalStack;
            cs.XLimMin = 0f;
            cs.XLimMax = 25f;
            cs.YLimMin = 0f;
            cs.YLimMax = 5f;
            cs.XTick = 5f;
            cs.YTick = 1f;
            cs.BarType = ChartStyle.BarTypeEnum.HorizontalStack;
        }

        private void AddData(Graphics g)
        {
            float x, y;
            // Add first data series:
            dc.DataSeriesList.Clear();
            ds = new DataSeries();
            ds.BarStyle.BorderColor = Color.Red;
            ds.BarStyle.FillColor = Color.Green;
            for (int i = 0; i < 5; i++)
            {
                x = i + 1;
                y = 2.0f * x;
                ds.AddPoint(new PointF(x, y));
            }
            dc.Add(ds);

            // Add second data series:
            ds = new DataSeries();
            ds.BarStyle.BorderColor = Color.Red;
            ds.BarStyle.FillColor = Color.Yellow;
            for (int i = 0; i < 5; i++)
            {
                x = i + 1;
                y = 1.5f * x;
                ds.AddPoint(new PointF(x, y));
            }
            dc.Add(ds);

            // Add third data series:
            ds = new DataSeries();
            ds.BarStyle.BorderColor = Color.Red;
            ds.BarStyle.FillColor = Color.Blue;
            for (int i = 0; i < 5; i++)
            {
                x = i + 1;
                y = 1.0f * x;
                ds.AddPoint(new PointF(x, y));
            }
            dc.Add(ds);
        }

        private void PlotPanelPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            AddData(g);
            cs.PlotPanelStyle(g);
            dc.AddBars(g, cs, dc.DataSeriesList.Count,
                  ds.PointList.Count);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            cs.ChartArea = this.ClientRectangle;
            cs.SetChartArea(g);
        }
    }
}