using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.Windows.Forms;

namespace Example4_3
{
    public partial class Form1 : Form
    {
        private DataCollection dc;
        private ChartStyle cs;

        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.ResizeRedraw, true);
            this.BackColor = Color.White;

            // Set Form1 size:
            this.Width = 350;
            this.Height = 350;
            dc = new DataCollection();
            cs = new ChartStyle(this);
            cs.XLimMin = 0f;
            cs.XLimMax = 8f;
            cs.YLimMin = -1.5f;
            cs.YLimMax = 1.5f;
            cs.XTick = 1.0f;
            cs.YTick = 0.5f;
            cs.XLabel = "This is X axis";
            cs.YLabel = "This is Y axis";
            cs.Title = "Sin(x)";
        }

        private void AddData(Graphics g)
        {
            dc.DataSeriesList.Clear();

            // Add Sine data points:
            DataSeries ds1 = new DataSeries();
            ds1.StairstepStyle.LineColor = Color.Red;

            for (int i = 0; i < 50; i++)
            {
                ds1.AddPoint(new PointF(0.4f * i,
                    (float)Math.Sin(0.4f * i)));
            }
            dc.Add(ds1);
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            cs.ChartArea = this.ClientRectangle;
            SetPlotArea(g);
            AddData(g);
            cs.AddChartStyle(g);
            //dc.AddLines(g, cs);
            dc.AddStairSteps(g, cs);
            g.Dispose();
        }

        private void SetPlotArea(Graphics g)
        {
            // Set PlotArea:
            float xOffset = cs.ChartArea.Width / 30.0f;
            float yOffset = cs.ChartArea.Height / 30.0f;
            SizeF labelFontSize = g.MeasureString("A", cs.LabelFont);
            SizeF titleFontSize = g.MeasureString("A", cs.TitleFont);
            if (cs.Title.ToUpper() == "NO TITLE")
            {
                titleFontSize.Width = 8f;
                titleFontSize.Height = 8f;
            }
            float xSpacing = xOffset / 3.0f;
            float ySpacing = yOffset / 3.0f;
            SizeF tickFontSize = g.MeasureString("A", cs.TickFont);
            float tickSpacing = 2f;
            SizeF yTickSize = g.MeasureString(cs.YLimMin.ToString(), cs.TickFont);
            for (float yTick = cs.YLimMin; yTick <= cs.YLimMax; yTick += cs.YTick)
            {
                SizeF tempSize = g.MeasureString(yTick.ToString(), cs.TickFont);
                if (yTickSize.Width < tempSize.Width)
                {
                    yTickSize = tempSize;
                }
            }
            float leftMargin = xOffset + labelFontSize.Width +
                        xSpacing + yTickSize.Width + tickSpacing;
            float rightMargin = 2 * xOffset;
            float topMargin = yOffset + titleFontSize.Height + ySpacing;
            float bottomMargin = yOffset + labelFontSize.Height +
                        ySpacing + tickSpacing + tickFontSize.Height;

            // Define the plot area with one Y axis:
            int plotX = cs.ChartArea.X + (int)leftMargin;
            int plotY = cs.ChartArea.Y + (int)topMargin;
            int plotWidth = cs.ChartArea.Width - (int)leftMargin - (int)rightMargin;
            int plotHeight = cs.ChartArea.Height - (int)topMargin - (int)bottomMargin;
            cs.PlotArea = new Rectangle(plotX, plotY, plotWidth, plotHeight);
        }
    }
}
