using System;
using System.Collections.Generic;
using System.Collections;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Example4_5
{
    public class DataCollection
    {
        private ArrayList dataSeriesList;
        private int dataSeriesIndex = 0;

        public DataCollection()
        {
            dataSeriesList = new ArrayList();
        }

        public ArrayList DataSeriesList
        {
            get { return dataSeriesList; }
            set { dataSeriesList = value; }
        }
        public int DataSeriesIndex
        {
            get { return dataSeriesIndex; }
            set { dataSeriesIndex = value; }
        }

        public void Add(DataSeries ds)
        {
            dataSeriesList.Add(ds);
            if (ds.SeriesName == "")
            {
                ds.SeriesName = "DataSeries" + dataSeriesList.Count.ToString();
            }
        }

        public void Insert(int dataSeriesIndex, DataSeries ds)
        {
            dataSeriesList.Insert(dataSeriesIndex, ds);
            if (ds.SeriesName == "")
            {
                dataSeriesIndex = dataSeriesIndex + 1;
                ds.SeriesName = "DataSeries" + dataSeriesIndex.ToString();
            }
        }

        public void Remove(string dataSeriesName)
        {
            if (dataSeriesList != null)
            {
                for (int i = 0; i < dataSeriesList.Count; i++)
                {
                    DataSeries ds = (DataSeries)dataSeriesList[i];
                    if (ds.SeriesName == dataSeriesName)
                    {
                        dataSeriesList.RemoveAt(i);
                    }
                }
            }
        }

        public void RemoveAll()
        {
            dataSeriesList.Clear();
        }

        public void AddLines(Graphics g, ChartStyle cs)
        {
            // Plot lines:
            foreach (DataSeries ds in DataSeriesList)
            {
                if (ds.LineStyle.IsVisible == true)
                {
                    Pen aPen = new Pen(ds.LineStyle.LineColor, ds.LineStyle.Thickness);
                    aPen.DashStyle = ds.LineStyle.Pattern;
                    if (ds.LineStyle.PlotMethod == LineStyle.PlotLinesMethodEnum.Lines)
                    {
                        for (int i = 1; i < ds.PointList.Count; i++)
                        {
                            g.DrawLine(aPen, cs.Point2D((PointF)ds.PointList[i - 1]),
                                             cs.Point2D((PointF)ds.PointList[i]));
                        }
                    }
                    else if (ds.LineStyle.PlotMethod == LineStyle.PlotLinesMethodEnum.Splines)
                    {
                        ArrayList al = new ArrayList();
                        for (int i = 0; i < ds.PointList.Count; i++)
                        {
                            PointF pt = (PointF)ds.PointList[i];
                            if (pt.X >= cs.XLimMin && pt.X <= cs.XLimMax &&
                                pt.Y >= cs.YLimMin && pt.Y <= cs.YLimMax)
                            {
                                al.Add(pt);
                            }
                        }
                        PointF[] pts = new PointF[al.Count];
                        for (int i = 0; i < pts.Length; i++)
                        {
                            pts[i] = cs.Point2D((PointF)(al[i]));
                        }
                        g.DrawCurve(aPen, pts);
                    }
                    aPen.Dispose();
                }
            }

            // Plot Symbols:
            foreach (DataSeries ds in DataSeriesList)
            {
                for (int i = 0; i < ds.PointList.Count; i++)
                {
                    PointF pt = (PointF)ds.PointList[i];
                    if (pt.X >= cs.XLimMin && pt.X <= cs.XLimMax &&
                        pt.Y >= cs.YLimMin && pt.Y <= cs.YLimMax)
                    {
                        ds.SymbolStyle.DrawSymbol(g, cs.Point2D((PointF)ds.PointList[i]));
                    }
                }
            }
        }

        public void AddStems(Graphics g, ChartStyle cs)
        {
            PointF pt = new PointF();
            PointF pt0 = new PointF();
            // Plot Stems:
            foreach (DataSeries ds in DataSeriesList)
            {
                Pen aPen = new Pen(ds.LineStyle.LineColor, ds.LineStyle.Thickness);
                aPen.DashStyle = ds.LineStyle.Pattern;
                if (ds.LineStyle.PlotMethod == LineStyle.PlotLinesMethodEnum.Lines)
                {
                    for (int i = 0; i < ds.PointList.Count; i++)
                    {
                        pt = (PointF)ds.PointList[i];
                        pt0 = new PointF(pt.X, 0);
                        g.DrawLine(aPen, cs.Point2D(pt0), cs.Point2D(pt));
                    }
                }
            }

            // Plot Symbols:
            foreach (DataSeries ds in DataSeriesList)
            {
                for (int i = 0; i < ds.PointList.Count; i++)
                {
                    pt = (PointF)ds.PointList[i];
                    if (pt.X >= cs.XLimMin && pt.X <= cs.XLimMax &&
                        pt.Y >= cs.YLimMin && pt.Y <= cs.YLimMax)
                    {
                        ds.SymbolStyle.DrawSymbol(g, cs.Point2D((PointF)ds.PointList[i]));
                    }
                }
            }
        }

        public void AddErrorBars(Graphics g, ChartStyle cs)
        {
            PointF pt = new PointF();
            PointF pt0 = new PointF();
            foreach (DataSeries ds in DataSeriesList)
            {
                Pen linePen = new Pen(ds.LineStyle.LineColor, ds.LineStyle.Thickness);
                linePen.DashStyle = ds.LineStyle.Pattern;
                Pen errorPen = new Pen(ds.ErrorbarStyle.LineColor, ds.ErrorbarStyle.Thickness);
                errorPen.DashStyle = ds.ErrorbarStyle.Pattern;
                float barLength = 0;
                
                // Draw lines:
                if (ds.LineStyle.PlotMethod == LineStyle.PlotLinesMethodEnum.Lines)
                {
                    for (int i = 1; i < ds.PointList.Count; i++)
                    {
                        pt0 = (PointF)ds.PointList[i - 1];
                        pt = (PointF)ds.PointList[i];
                        g.DrawLine(linePen, cs.Point2D(pt0), cs.Point2D(pt));
                        barLength = (pt.X - pt0.X) / 4;
                    }
                }
                // Draw error bars:
                for (int i = 0; i < ds.ErrorList.Count; i++)
                {
                    PointF errorPoint = (PointF)ds.ErrorList[i];
                    PointF linePoint = (PointF)ds.PointList[i];
                    pt0 = new PointF(linePoint.X, linePoint.Y - errorPoint.Y / 2);
                    pt = new PointF(linePoint.X, linePoint.Y + errorPoint.Y / 2);
                    g.DrawLine(errorPen, cs.Point2D(pt0), cs.Point2D(pt));
                    PointF pt1 = new PointF(pt0.X - barLength / 2, pt0.Y);
                    PointF pt2 = new PointF(pt0.X + barLength / 2, pt0.Y);
                    g.DrawLine(errorPen, cs.Point2D(pt1), cs.Point2D(pt2));
                    pt1 = new PointF(pt.X - barLength / 2, pt.Y);
                    pt2 = new PointF(pt.X + barLength / 2, pt.Y);
                    g.DrawLine(errorPen, cs.Point2D(pt1), cs.Point2D(pt2));
                }
                linePen.Dispose();
                errorPen.Dispose();
            }
        }
    }
}
