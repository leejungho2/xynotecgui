using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Drawing;

namespace Example4_5
{
    public class DataSeries
    {
        private ArrayList pointList;
        private LineStyle lineStyle;
        private SymbolStyle symbolStyle;
        private string seriesName = "";
        private ErrorbarStyle errorbarStyle;
        private ArrayList errorList;

        public DataSeries()
        {
            lineStyle = new LineStyle();
            SymbolStyle = new SymbolStyle();
            pointList = new ArrayList();
            errorbarStyle = new ErrorbarStyle();
            errorList = new ArrayList();
        }

        public ArrayList ErrorList
        {
            get { return errorList; }
            set { errorList = value; }
        }

        public void AddErrorData(PointF pt)
        {
            errorList.Add(pt);
        }

        public ErrorbarStyle ErrorbarStyle
        {
            get { return errorbarStyle; }
            set { errorbarStyle = value; }
        }

        public LineStyle LineStyle
        {
            get { return lineStyle; }
            set { lineStyle = value; }
        }

        public SymbolStyle SymbolStyle
        {
            get { return symbolStyle; }
            set { symbolStyle = value; }
        }

        public ArrayList PointList
        {
            get { return pointList; }
            set { pointList = value; }
        }

        public void AddPoint(PointF pt)
        {
            pointList.Add(pt);
        }

        public string SeriesName
        {
            get { return seriesName; }
            set { seriesName = value; }
        }
    }
}


