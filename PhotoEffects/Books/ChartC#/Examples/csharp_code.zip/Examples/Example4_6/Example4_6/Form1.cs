using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Example4_6
{
    public partial class Form1 : Form
    {
        private ChartStyle cs;
        private DataSeries ds;
        private ColorMap cm;
        private Legend lg;

        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            // Subscribing to a paint eventhandler to drawingPanel: 
            PlotPanel.Paint +=
                new PaintEventHandler(PlotPanelPaint);

            cs = new ChartStyle(this);
            ds = new DataSeries();
            lg = new Legend(this);
            lg.IsLegendVisible = true;
        }

        private void AddData()
        {
            // Create a standard pie chart:
            float[] data = new float[5] { 30, 35, 15, 10, 8 };
            string[] labels = new string[5] { "Soc. Sec. Tax", "Income Tax", 
                "Borrowing", "Corp. Tax", "Misc." };
            cm = new ColorMap(data.Length);
            ds.CMap = cm.Jet();
            ds.DataList.Clear();
            for (int i = 0; i < data.Length; i++)
            {
                ds.AddData(data[i]);
                ds.LabelList[i] = labels[i];
            }
            ds.ExplodeList[0] = 15;

            // Create a partial pie:
            /*float[] data = new float[3] { 0.3f, 0.1f, 0.25f};
            string[] labels = new string[3] { "0.3 -- 30%", "0.1 -- 10%", 
                "0.25 -- 25%"};
            cm = new ColorMap(data.Length);
            ds.CMap = cm.Cool();
            ds.DataList.Clear();
            for (int i = 0; i < data.Length; i++)
            {
                ds.AddData(data[i]);
                ds.LabelList[i] = labels[i];
            }*/
        }

        private void PlotPanelPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            AddData();
            ds.AddPie(g, cs);
            lg.AddLegend(g, ds, cs);
        }
    }
}