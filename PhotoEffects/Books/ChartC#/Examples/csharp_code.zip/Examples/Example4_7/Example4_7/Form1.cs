using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Example4_7
{
    public partial class Form1 : Form
    {
        private DataCollection dc;
        private DataSeries ds;
        private ChartStyle cs;
        private ColorMap cm;

        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.BackColor = Color.White;

            // Subscribing to a paint eventhandler to drawingPanel: 
            PlotPanel.Paint +=
                new PaintEventHandler(PlotPanelPaint);

            dc = new DataCollection();
            cs = new ChartStyle(this);
            cs.XLimMin = 0f;
            cs.XLimMax = 10f;
            cs.YLimMin = 0f;
            cs.YLimMax = 10f;
            cs.XTick = 2.0f;
            cs.YTick = 2.0f;
            cs.XLabel = "This is X axis";
            cs.YLabel = "This is Y axis";
            cs.Title = "Area Plot";
            cs.IsXGrid = true;
            cs.IsYGrid = true;
        }

        private void AddData()
        {
            dc.DataSeriesList.Clear();
            // Add Sine data:
            ds = new DataSeries();
            for (int i = 0; i < 21; i++)
            {
                ds.AddPoint(new PointF(0.5f * i,
                    2.0f + (float)Math.Sin(0.5f * i)));
            }
            dc.Add(ds);

            // Add Cosine data:
            ds = new DataSeries();
            for (int i = 0; i < 21; i++)
            {
                ds.AddPoint(new PointF(0.5f * i,
                    2.0f + (float)Math.Cos(0.5f * i)));
            }
            dc.Add(ds);

            // Add another Sine data:
            ds = new DataSeries();
            for (int i = 0; i < 21; i++)
            {
                ds.AddPoint(new PointF(0.5f * i,
                    3.0f + (float)Math.Sin(0.5f * i)));
            }
            dc.Add(ds);


            cm = new ColorMap(dc.DataSeriesList.Count, 150);
            dc.CMap = cm.Summer();
        }

        private void PlotPanelPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            AddData();
            cs.PlotPanelStyle(g);
            dc.AddAreas(g, cs, dc.DataSeriesList.Count, ds.PointList.Count);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            cs.ChartArea = this.ClientRectangle;
            cs.SetChartArea(g);
        }
    }
}