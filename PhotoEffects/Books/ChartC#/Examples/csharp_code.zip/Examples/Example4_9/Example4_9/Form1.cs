using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Example4_9
{
    public partial class Form1 : Form
    {
        private ChartStyle cs;
        private DataCollection dc;

        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.BackColor = Color.White;

            // Subscribing to a paint eventhandler to drawingPanel: 
            PlotPanel.Paint +=
                new PaintEventHandler(PlotPanelPaint);

            cs = new ChartStyle(this);
            dc = new DataCollection(this);
            // Specify chart style parameters:
            cs.Title = "Chart of GE Stock";
            cs.XTickOffset = 1;
            cs.XLimMin = -1f;
            cs.XLimMax = 20f;
            cs.YLimMin = 32f;
            cs.YLimMax = 36f;
            cs.XTick = 2f;
            cs.YTick = 0.5f;
            dc.StockChartType = DataCollection.StockChartTypeEnum.HiLoOpenClose;
        }

        private void AddData()
        {
            dc.DataSeriesList.Clear();
            TextFileReader tfr = new TextFileReader();
            DataSeries ds = new DataSeries();

            // Add GE stock data from a text data file:
            ds = new DataSeries();
            ds.DataString = tfr.ReadTextFile("GE.txt");
            ds.LineStyle.LineColor = Color.DarkBlue;
            dc.Add(ds);         
        }

        private void PlotPanelPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            AddData();
            cs.PlotPanelStyle(g);
            dc.AddStockChart(g, cs);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            cs.ChartArea = this.ClientRectangle;
            cs.SetChartArea(g);
        }
    }
}