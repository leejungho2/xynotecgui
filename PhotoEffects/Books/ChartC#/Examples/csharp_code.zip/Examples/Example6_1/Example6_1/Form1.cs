using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Example6_1
{
    public partial class Form1 : Form
    {
        ChartStyle cs;
     
        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | 
                ControlStyles.UserPaint | 
                ControlStyles.DoubleBuffer,true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.BackColor = Color.White;

            // Subscribing to a paint eventhandler to drawingPanel: 
            PlotPanel.Paint +=
                new PaintEventHandler(PlotPanelPaint);
            cs = new ChartStyle(this);
            cs.GridStyle.LineColor = Color.LightGray;
            cs.GridStyle.Pattern = DashStyle.Dash;
            cs.AxisStyle.LineColor = Color.Blue;
            cs.AxisStyle.Thickness = 2;
            cs.YTick = 1f;
        }

        private void PlotPanelPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            cs.Elevation = trkElevation.Value;
            cs.Azimuth = trkAzimuth.Value;
            cs.AddChartStyle(g);
            
        }

        private void trkElevation_Scroll(object sender, EventArgs e)
        {
            tbElevation.Text = trkElevation.Value.ToString();
            PlotPanel.Invalidate();
        }

        private void trkAzimuth_Scroll(object sender, EventArgs e)
        {
            tbAzimuth.Text = trkAzimuth.Value.ToString();
            PlotPanel.Invalidate();
        }

        private void tbElevation_KeyUp(object sender, KeyEventArgs e)
        {
            int value;
            bool result = Int32.TryParse(tbElevation.Text, out value);
            if (result)
            {
                if (value <= -90)
                    value = -90;
                else if (value >= 90)
                    value = 90;
                trkElevation.Value = value;
            }
            PlotPanel.Invalidate();
        }

        private void tbAzimuth_KeyUp(object sender, KeyEventArgs e)
        {
            int value;
            bool result = Int32.TryParse(tbAzimuth.Text, out value);
            if (result)
            {
                if (value <= -180)
                    value = -180;
                else if (value >= 180)
                    value = 180;
                trkAzimuth.Value = value;
            }
            PlotPanel.Invalidate();
        }
    }
}