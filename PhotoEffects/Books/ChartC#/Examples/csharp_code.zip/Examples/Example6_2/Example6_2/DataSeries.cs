using System;
using System.Collections;
using System.Drawing;

namespace Example6_2
{
    public class DataSeries
    {
        private ArrayList pointList;
        private LineStyle lineStyle;

        public DataSeries()
        {
            lineStyle = new LineStyle();
            pointList = new ArrayList();
        }

        public LineStyle LineStyle
        {
            get { return lineStyle; }
            set { lineStyle = value; }
        }

        public ArrayList PointList
        {
            get { return pointList; }
            set { pointList = value; }
        }

        public void AddPoint(Point3 pt)
        {
            PointList.Add(pt);
        }
    }
}

