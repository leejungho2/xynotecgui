using System;
using System.Drawing;
using System.Windows.Forms;

namespace Example6_2
{
    public class DrawChart
    {
        Form1 form1;
        public DrawChart(Form1 fm1)
        {
            form1 = fm1;
        }

        public void AddLine(Graphics g, DataSeries ds, ChartStyle cs)
        {
            Pen aPen = new Pen(ds.LineStyle.LineColor, ds.LineStyle.Thickness);
            aPen.DashStyle = ds.LineStyle.Pattern;
            Matrix3 m = Matrix3.AzimuthElevation(cs.Elevation, cs.Azimuth);
            Point3[] pts = new Point3[ds.PointList.Count];

            for (int i = 0; i < pts.Length; i++)
            {
                pts[i] = (Point3)ds.PointList[i];
                pts[i].Transform(m, form1, cs);
            }

            // Draw line:
            if (ds.LineStyle.IsVisible == true)
            {
                for (int i = 1; i < pts.Length; i++)
                {
                    g.DrawLine(aPen, pts[i - 1].X, pts[i - 1].Y, pts[i].X, pts[i].Y);
                }
                aPen.Dispose();            
            }
        }
    }
}
