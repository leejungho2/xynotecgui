namespace Example7_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Chart2DLib.DataCollection dataCollection5 = new Chart2DLib.DataCollection();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Chart2DLib.DataCollection dataCollection6 = new Chart2DLib.DataCollection();
            Chart2DLib.DataCollection dataCollection7 = new Chart2DLib.DataCollection();
            Chart2DLib.DataCollection dataCollection8 = new Chart2DLib.DataCollection();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.chart2D1 = new Chart2DLib.Chart2D();
            this.chart2D2 = new Chart2DLib.Chart2D();
            this.chart2D3 = new Chart2DLib.Chart2D();
            this.chart2D4 = new Chart2DLib.Chart2D();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.81522F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.18478F));
            this.tableLayoutPanel1.Controls.Add(this.chart2D1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.chart2D2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.chart2D3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.chart2D4, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(8, 8);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(504, 488);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // chart2D1
            // 
            this.chart2D1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chart2D1.C2ChartArea.ChartBackColor = System.Drawing.Color.White;
            this.chart2D1.C2ChartArea.ChartBorderColor = System.Drawing.SystemColors.Control;
            this.chart2D1.C2ChartArea.PlotBackColor = System.Drawing.Color.White;
            this.chart2D1.C2ChartArea.PlotBorderColor = System.Drawing.Color.Black;
            dataCollection5.DataSeriesIndex = 0;
            dataCollection5.DataSeriesList = ((System.Collections.ArrayList)(resources.GetObject("dataCollection5.DataSeriesList")));
            this.chart2D1.C2DataCollection = dataCollection5;
            this.chart2D1.C2Grid.GridColor = System.Drawing.Color.LightGray;
            this.chart2D1.C2Grid.GridPattern = System.Drawing.Drawing2D.DashStyle.Solid;
            this.chart2D1.C2Grid.GridThickness = 1F;
            this.chart2D1.C2Grid.IsXGrid = true;
            this.chart2D1.C2Grid.IsYGrid = true;
            this.chart2D1.C2Label.LabelFont = new System.Drawing.Font("Arial", 10F);
            this.chart2D1.C2Label.LabelFontColor = System.Drawing.Color.Black;
            this.chart2D1.C2Label.TickFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chart2D1.C2Label.TickFontColor = System.Drawing.Color.Black;
            this.chart2D1.C2Label.XLabel = "X Axis";
            this.chart2D1.C2Label.Y2Label = "Y2 Axis";
            this.chart2D1.C2Label.YLabel = "Y Axis";
            this.chart2D1.C2Legend.IsBorderVisible = true;
            this.chart2D1.C2Legend.IsLegendVisible = false;
            this.chart2D1.C2Legend.LegendBackColor = System.Drawing.Color.White;
            this.chart2D1.C2Legend.LegendBorderColor = System.Drawing.Color.Black;
            this.chart2D1.C2Legend.LegendFont = new System.Drawing.Font("Arial", 8F);
            this.chart2D1.C2Legend.LegendPosition = Chart2DLib.Legend.LegendPositionEnum.NorthEast;
            this.chart2D1.C2Legend.TextColor = System.Drawing.Color.Black;
            this.chart2D1.C2Title.Title = "Title";
            this.chart2D1.C2Title.TitleFont = new System.Drawing.Font("Arial", 12F);
            this.chart2D1.C2Title.TitleFontColor = System.Drawing.Color.Black;
            this.chart2D1.C2XAxis.XLimMax = 10F;
            this.chart2D1.C2XAxis.XLimMin = 0F;
            this.chart2D1.C2XAxis.XTick = 2F;
            this.chart2D1.C2Y2Axis.IsY2Axis = false;
            this.chart2D1.C2Y2Axis.Y2LimMax = 100F;
            this.chart2D1.C2Y2Axis.Y2LimMin = 0F;
            this.chart2D1.C2Y2Axis.Y2Tick = 20F;
            this.chart2D1.C2YAxis.YLimMax = 10F;
            this.chart2D1.C2YAxis.YLimMin = 0F;
            this.chart2D1.C2YAxis.YTick = 2F;
            this.chart2D1.Location = new System.Drawing.Point(3, 3);
            this.chart2D1.Name = "chart2D1";
            this.chart2D1.Size = new System.Drawing.Size(229, 221);
            this.chart2D1.TabIndex = 0;
            // 
            // chart2D2
            // 
            this.chart2D2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chart2D2.C2ChartArea.ChartBackColor = System.Drawing.Color.White;
            this.chart2D2.C2ChartArea.ChartBorderColor = System.Drawing.SystemColors.Control;
            this.chart2D2.C2ChartArea.PlotBackColor = System.Drawing.Color.White;
            this.chart2D2.C2ChartArea.PlotBorderColor = System.Drawing.Color.Black;
            dataCollection6.DataSeriesIndex = 0;
            dataCollection6.DataSeriesList = ((System.Collections.ArrayList)(resources.GetObject("dataCollection6.DataSeriesList")));
            this.chart2D2.C2DataCollection = dataCollection6;
            this.chart2D2.C2Grid.GridColor = System.Drawing.Color.LightGray;
            this.chart2D2.C2Grid.GridPattern = System.Drawing.Drawing2D.DashStyle.Solid;
            this.chart2D2.C2Grid.GridThickness = 1F;
            this.chart2D2.C2Grid.IsXGrid = true;
            this.chart2D2.C2Grid.IsYGrid = true;
            this.chart2D2.C2Label.LabelFont = new System.Drawing.Font("Arial", 10F);
            this.chart2D2.C2Label.LabelFontColor = System.Drawing.Color.Black;
            this.chart2D2.C2Label.TickFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chart2D2.C2Label.TickFontColor = System.Drawing.Color.Black;
            this.chart2D2.C2Label.XLabel = "X Axis";
            this.chart2D2.C2Label.Y2Label = "Y2 Axis";
            this.chart2D2.C2Label.YLabel = "Y Axis";
            this.chart2D2.C2Legend.IsBorderVisible = true;
            this.chart2D2.C2Legend.IsLegendVisible = false;
            this.chart2D2.C2Legend.LegendBackColor = System.Drawing.Color.White;
            this.chart2D2.C2Legend.LegendBorderColor = System.Drawing.Color.Black;
            this.chart2D2.C2Legend.LegendFont = new System.Drawing.Font("Arial", 8F);
            this.chart2D2.C2Legend.LegendPosition = Chart2DLib.Legend.LegendPositionEnum.NorthEast;
            this.chart2D2.C2Legend.TextColor = System.Drawing.Color.Black;
            this.chart2D2.C2Title.Title = "Title";
            this.chart2D2.C2Title.TitleFont = new System.Drawing.Font("Arial", 12F);
            this.chart2D2.C2Title.TitleFontColor = System.Drawing.Color.Black;
            this.chart2D2.C2XAxis.XLimMax = 10F;
            this.chart2D2.C2XAxis.XLimMin = 0F;
            this.chart2D2.C2XAxis.XTick = 2F;
            this.chart2D2.C2Y2Axis.IsY2Axis = false;
            this.chart2D2.C2Y2Axis.Y2LimMax = 100F;
            this.chart2D2.C2Y2Axis.Y2LimMin = 0F;
            this.chart2D2.C2Y2Axis.Y2Tick = 20F;
            this.chart2D2.C2YAxis.YLimMax = 10F;
            this.chart2D2.C2YAxis.YLimMin = 0F;
            this.chart2D2.C2YAxis.YTick = 2F;
            this.chart2D2.Location = new System.Drawing.Point(259, 3);
            this.chart2D2.Name = "chart2D2";
            this.chart2D2.Size = new System.Drawing.Size(229, 229);
            this.chart2D2.TabIndex = 1;
            // 
            // chart2D3
            // 
            this.chart2D3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chart2D3.C2ChartArea.ChartBackColor = System.Drawing.Color.White;
            this.chart2D3.C2ChartArea.ChartBorderColor = System.Drawing.SystemColors.Control;
            this.chart2D3.C2ChartArea.PlotBackColor = System.Drawing.Color.White;
            this.chart2D3.C2ChartArea.PlotBorderColor = System.Drawing.Color.Black;
            dataCollection7.DataSeriesIndex = 0;
            dataCollection7.DataSeriesList = ((System.Collections.ArrayList)(resources.GetObject("dataCollection7.DataSeriesList")));
            this.chart2D3.C2DataCollection = dataCollection7;
            this.chart2D3.C2Grid.GridColor = System.Drawing.Color.LightGray;
            this.chart2D3.C2Grid.GridPattern = System.Drawing.Drawing2D.DashStyle.Solid;
            this.chart2D3.C2Grid.GridThickness = 1F;
            this.chart2D3.C2Grid.IsXGrid = true;
            this.chart2D3.C2Grid.IsYGrid = true;
            this.chart2D3.C2Label.LabelFont = new System.Drawing.Font("Arial", 10F);
            this.chart2D3.C2Label.LabelFontColor = System.Drawing.Color.Black;
            this.chart2D3.C2Label.TickFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chart2D3.C2Label.TickFontColor = System.Drawing.Color.Black;
            this.chart2D3.C2Label.XLabel = "X Axis";
            this.chart2D3.C2Label.Y2Label = "Y2 Axis";
            this.chart2D3.C2Label.YLabel = "Y Axis";
            this.chart2D3.C2Legend.IsBorderVisible = true;
            this.chart2D3.C2Legend.IsLegendVisible = false;
            this.chart2D3.C2Legend.LegendBackColor = System.Drawing.Color.White;
            this.chart2D3.C2Legend.LegendBorderColor = System.Drawing.Color.Black;
            this.chart2D3.C2Legend.LegendFont = new System.Drawing.Font("Arial", 8F);
            this.chart2D3.C2Legend.LegendPosition = Chart2DLib.Legend.LegendPositionEnum.NorthEast;
            this.chart2D3.C2Legend.TextColor = System.Drawing.Color.Black;
            this.chart2D3.C2Title.Title = "Title";
            this.chart2D3.C2Title.TitleFont = new System.Drawing.Font("Arial", 12F);
            this.chart2D3.C2Title.TitleFontColor = System.Drawing.Color.Black;
            this.chart2D3.C2XAxis.XLimMax = 10F;
            this.chart2D3.C2XAxis.XLimMin = 0F;
            this.chart2D3.C2XAxis.XTick = 2F;
            this.chart2D3.C2Y2Axis.IsY2Axis = false;
            this.chart2D3.C2Y2Axis.Y2LimMax = 100F;
            this.chart2D3.C2Y2Axis.Y2LimMin = 0F;
            this.chart2D3.C2Y2Axis.Y2Tick = 20F;
            this.chart2D3.C2YAxis.YLimMax = 10F;
            this.chart2D3.C2YAxis.YLimMin = 0F;
            this.chart2D3.C2YAxis.YTick = 2F;
            this.chart2D3.Location = new System.Drawing.Point(3, 247);
            this.chart2D3.Name = "chart2D3";
            this.chart2D3.Size = new System.Drawing.Size(237, 209);
            this.chart2D3.TabIndex = 2;
            // 
            // chart2D4
            // 
            this.chart2D4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chart2D4.C2ChartArea.ChartBackColor = System.Drawing.Color.White;
            this.chart2D4.C2ChartArea.ChartBorderColor = System.Drawing.SystemColors.Control;
            this.chart2D4.C2ChartArea.PlotBackColor = System.Drawing.Color.White;
            this.chart2D4.C2ChartArea.PlotBorderColor = System.Drawing.Color.Black;
            dataCollection8.DataSeriesIndex = 0;
            dataCollection8.DataSeriesList = ((System.Collections.ArrayList)(resources.GetObject("dataCollection8.DataSeriesList")));
            this.chart2D4.C2DataCollection = dataCollection8;
            this.chart2D4.C2Grid.GridColor = System.Drawing.Color.LightGray;
            this.chart2D4.C2Grid.GridPattern = System.Drawing.Drawing2D.DashStyle.Solid;
            this.chart2D4.C2Grid.GridThickness = 1F;
            this.chart2D4.C2Grid.IsXGrid = true;
            this.chart2D4.C2Grid.IsYGrid = true;
            this.chart2D4.C2Label.LabelFont = new System.Drawing.Font("Arial", 10F);
            this.chart2D4.C2Label.LabelFontColor = System.Drawing.Color.Black;
            this.chart2D4.C2Label.TickFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chart2D4.C2Label.TickFontColor = System.Drawing.Color.Black;
            this.chart2D4.C2Label.XLabel = "X Axis";
            this.chart2D4.C2Label.Y2Label = "Y2 Axis";
            this.chart2D4.C2Label.YLabel = "Y Axis";
            this.chart2D4.C2Legend.IsBorderVisible = true;
            this.chart2D4.C2Legend.IsLegendVisible = false;
            this.chart2D4.C2Legend.LegendBackColor = System.Drawing.Color.White;
            this.chart2D4.C2Legend.LegendBorderColor = System.Drawing.Color.Black;
            this.chart2D4.C2Legend.LegendFont = new System.Drawing.Font("Arial", 8F);
            this.chart2D4.C2Legend.LegendPosition = Chart2DLib.Legend.LegendPositionEnum.NorthEast;
            this.chart2D4.C2Legend.TextColor = System.Drawing.Color.Black;
            this.chart2D4.C2Title.Title = "Title";
            this.chart2D4.C2Title.TitleFont = new System.Drawing.Font("Arial", 12F);
            this.chart2D4.C2Title.TitleFontColor = System.Drawing.Color.Black;
            this.chart2D4.C2XAxis.XLimMax = 10F;
            this.chart2D4.C2XAxis.XLimMin = 0F;
            this.chart2D4.C2XAxis.XTick = 2F;
            this.chart2D4.C2Y2Axis.IsY2Axis = false;
            this.chart2D4.C2Y2Axis.Y2LimMax = 100F;
            this.chart2D4.C2Y2Axis.Y2LimMin = 0F;
            this.chart2D4.C2Y2Axis.Y2Tick = 20F;
            this.chart2D4.C2YAxis.YLimMax = 10F;
            this.chart2D4.C2YAxis.YLimMin = 0F;
            this.chart2D4.C2YAxis.YTick = 2F;
            this.chart2D4.Location = new System.Drawing.Point(259, 247);
            this.chart2D4.Name = "chart2D4";
            this.chart2D4.Size = new System.Drawing.Size(229, 217);
            this.chart2D4.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(522, 506);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Chart2DLib.Chart2D chart2D1;
        private Chart2DLib.Chart2D chart2D2;
        private Chart2DLib.Chart2D chart2D3;
        private Chart2DLib.Chart2D chart2D4;
    }
}

