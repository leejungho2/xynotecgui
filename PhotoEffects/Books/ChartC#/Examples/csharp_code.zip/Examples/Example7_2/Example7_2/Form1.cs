using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Chart2DLib;

namespace Example7_2
{
    public partial class Form1 : Form
    {
        private DataSeries ds;

        public Form1()
        {
            InitializeComponent();
            tableLayoutPanel1.Dock = DockStyle.Fill;
            chart2D1.Dock = DockStyle.Fill;
            chart2D2.Dock = DockStyle.Fill;
            chart2D3.Dock = DockStyle.Fill;
            chart2D4.Dock = DockStyle.Fill;
            ds = new DataSeries();
            chart2D4.C2Legend.IsLegendVisible = true;
            AddData();
        }

        private void AddData()
        {
            float x, y, x2, y2;
            // Create sub-chart 1 (0, 0):
            // Parameters for sub-chart 1 (0, 0):
            chart2D1.C2Label.TickFont = new Font("Arial", 7, FontStyle.Regular);
            chart2D1.C2Title.TitleFont = new Font("Arial", 10, FontStyle.Regular);
            chart2D1.C2XAxis.XLimMin = 0f;
            chart2D1.C2XAxis.XLimMax = 7f;
            chart2D1.C2YAxis.YLimMin = -1.5f;
            chart2D1.C2YAxis.YLimMax = 1.5f;
            chart2D1.C2XAxis.XTick = 1.0f;
            chart2D1.C2YAxis.YTick = 0.5f;
            chart2D1.C2Title.Title = "Sin(x)";
            // Add Sin(x) data to sub-chart 1:
            chart2D1.C2DataCollection.DataSeriesList.Clear();
            ds = new DataSeries();
            ds.LineStyle.LineColor = Color.Red;
            ds.LineStyle.Thickness = 2f;
            ds.LineStyle.Pattern = DashStyle.Dash;
            for (int i = 0; i < 50; i++)
            {
                x = i / 5.0f;
                y = (float)Math.Sin(x);
                ds.AddPoint(new PointF(x, y));
            }
            chart2D1.C2DataCollection.Add(ds);

            // Create sub-chart 2 (0, 1):
            // Parameters for sub-chart 2 (0, 1):
            chart2D2.C2Label.TickFont = new Font("Arial", 7, FontStyle.Regular);
            chart2D2.C2Title.TitleFont = new Font("Arial", 10, FontStyle.Regular);
            chart2D2.C2XAxis.XLimMin = 0f;
            chart2D2.C2XAxis.XLimMax = 7f;
            chart2D2.C2YAxis.YLimMin = -1.5f;
            chart2D2.C2YAxis.YLimMax = 1.5f;
            chart2D2.C2XAxis.XTick = 1.0f;
            chart2D2.C2YAxis.YTick = 0.5f;
            chart2D2.C2Title.Title = "Cos(x)";
            // Add Cos(x) data sub-chart 2:
            chart2D2.C2DataCollection.DataSeriesList.Clear();
            ds = new DataSeries();
            ds.LineStyle.LineColor = Color.Blue;
            ds.LineStyle.Thickness = 1f;
            ds.SymbolStyle.SymbolType =
             SymbolStyle.SymbolTypeEnum.OpenDiamond;
            for (int i = 0; i < 50; i++)
            {
                x = i / 5.0f;
                y = (float)Math.Cos(x);
                ds.AddPoint(new PointF(x, y));
            }
            chart2D2.C2DataCollection.Add(ds);

            // Create sub-chart 3 (1, 0):
            // Parameters for sub-chart 3 (1, 0):
            chart2D3.C2Label.TickFont = new Font("Arial", 7, FontStyle.Regular);
            chart2D3.C2Title.TitleFont = new Font("Arial", 10, FontStyle.Regular);
            chart2D3.C2XAxis.XLimMin = 0f;
            chart2D3.C2XAxis.XLimMax = 7f;
            chart2D3.C2YAxis.YLimMin = -0.5f;
            chart2D3.C2YAxis.YLimMax = 1.5f;
            chart2D3.C2XAxis.XTick = 1.0f;
            chart2D3.C2YAxis.YTick = 0.5f;
            chart2D3.C2Title.Title = "Sin(x)^2";
            // Add Sin(x)^2 data to sub-chart 3:
            chart2D3.C2DataCollection.DataSeriesList.Clear();
            ds = new DataSeries();
            ds.LineStyle.IsVisible = false;
            ds.SymbolStyle.SymbolType = SymbolStyle.SymbolTypeEnum.Dot;
            ds.SymbolStyle.FillColor = Color.Yellow;
            ds.SymbolStyle.BorderColor = Color.DarkCyan;
            for (int i = 0; i < 50; i++)
            {
                x = i / 5.0f;
                y = (float)Math.Sin(x);
                ds.AddPoint(new PointF(x, y * y));
            }
            chart2D3.C2DataCollection.Add(ds);

            // Create sub-chart 4 (1, 1):
            // Parameters for sub-chart 4 (1, 1):
            chart2D4.C2Y2Axis.IsY2Axis = true;
            chart2D4.C2Grid.IsXGrid = false;
            chart2D4.C2Grid.IsYGrid = false;
            chart2D4.C2Label.TickFont = new Font("Arial", 7, FontStyle.Regular);
            chart2D4.C2Title.TitleFont = new Font("Arial", 10, FontStyle.Regular);
            chart2D4.C2XAxis.XLimMin = 0f;
            chart2D4.C2XAxis.XLimMax = 30f;
            chart2D4.C2YAxis.YLimMin = -20f;
            chart2D4.C2YAxis.YLimMax = 20f;
            chart2D4.C2XAxis.XTick = 5.0f;
            chart2D4.C2YAxis.YTick = 5f;
            chart2D4.C2Y2Axis.Y2LimMin = 100f;
            chart2D4.C2Y2Axis.Y2LimMax = 700f;
            chart2D4.C2Y2Axis.Y2Tick = 100f;
            chart2D4.C2Label.XLabel = "X Axis";
            chart2D4.C2Label.YLabel = "Y Axis";
            chart2D4.C2Label.Y2Label = "Y2 Axis";
            chart2D4.C2Title.Title = "With Y2 Axis";
            chart2D4.C2Legend.IsLegendVisible = true;
            chart2D4.C2Legend.LegendPosition = Legend.LegendPositionEnum.SouthEast;
            // Add y1 and y2 data to sub-chart 4:
            chart2D4.C2DataCollection.DataSeriesList.Clear();
            // Add y1 data:
            ds = new DataSeries();
            ds.LineStyle.LineColor = Color.Red;
            ds.LineStyle.Thickness = 2f;
            ds.LineStyle.Pattern = DashStyle.Dash;
            ds.SeriesName = "x1*cos(x1)";
            for (int i = 0; i < 20; i++)
            {
                float x1 = 1.0f * i;
                float y1 = x1 * (float)Math.Cos(x1);
                ds.AddPoint(new PointF(x1, y1));
            }
            chart2D4.C2DataCollection.Add(ds);
            // Add y2 data:
            ds = new DataSeries();
            ds.LineStyle.LineColor = Color.Blue;
            ds.LineStyle.Thickness = 2f;
            ds.SeriesName = "100 + 20*x2";
            ds.IsY2Data = true;
            for (int i = 5; i < 30; i++)
            {
                x2 = 1.0f * i;
                y2 = 100.0f + 20.0f * x2;
                ds.AddPoint(new PointF(x2, y2));
            }
            chart2D4.C2DataCollection.Add(ds);
        }
    }
}