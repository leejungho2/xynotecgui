using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Chart3DLib;

namespace Example7_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            chart3D1.Dock = DockStyle.Fill;
            chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Line;
            chart3D1.C3Labels.Title = "No Title";
            chart3D1.C3DrawChart.IsColorMap = false;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            AddData();
        }

        private void AddData()
        {
            chart3D1.C3Axes.XMin = -1;
            chart3D1.C3Axes.XMax = 1;
            chart3D1.C3Axes.YMin = -1;
            chart3D1.C3Axes.YMax = 1;
            chart3D1.C3Axes.ZMin = 0;
            chart3D1.C3Axes.ZMax = 30;
            chart3D1.C3Axes.XTick = 0.5f;
            chart3D1.C3Axes.YTick = 0.5f;
            chart3D1.C3Axes.ZTick = 5;

            chart3D1.C3DataSeries.PointList.Clear();
            chart3D1.C3DataSeries.LineStyle.LineColor = Color.Red;
            for (int i = 0; i < 300; i++)
            {
                float t = 0.1f * i;
                float x = (float)Math.Exp(-t / 30) *
                    (float)Math.Cos(t);
                float y = (float)Math.Exp(-t / 30) *
                    (float)Math.Sin(t);
                float z = t;
                chart3D1.C3DataSeries.AddPoint(new Point3(x, y, z, 1));
            }
        }
    }
}