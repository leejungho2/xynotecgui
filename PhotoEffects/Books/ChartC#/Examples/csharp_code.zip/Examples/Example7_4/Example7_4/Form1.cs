using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Chart3DLib;

namespace Example7_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Bar3D;
            chart3D1.C3ChartStyle.IsColorBar = true;
            chart3D1.Dock = DockStyle.Fill;
            chart3D1.C3DataSeries.BarStyle.XLength = 0.3f;
            chart3D1.C3DataSeries.BarStyle.YLength = 0.3f;
            chart3D1.C3DataSeries.BarStyle.IsBarSingleColor = false;
            chart3D1.C3DataSeries.BarStyle.ZOrigin = -8;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            AddData();
        }

        private void AddData()
        {
            chart3D1.C3Axes.XMin = -3;
            chart3D1.C3Axes.XMax = 3;
            chart3D1.C3Axes.YMin = -3;
            chart3D1.C3Axes.YMax = 3;
            chart3D1.C3Axes.ZMin = -8;
            chart3D1.C3Axes.ZMax = 8;
            chart3D1.C3Axes.XTick = 1;
            chart3D1.C3Axes.YTick = 1;
            chart3D1.C3Axes.ZTick = 4;

            chart3D1.C3DataSeries.XDataMin = chart3D1.C3Axes.XMin;
            chart3D1.C3DataSeries.YDataMin = chart3D1.C3Axes.YMin;
            chart3D1.C3DataSeries.XSpacing = 0.5f;
            chart3D1.C3DataSeries.YSpacing = 0.5f;
            chart3D1.C3DataSeries.XNumber = Convert.ToInt16((chart3D1.C3Axes.XMax -
                chart3D1.C3Axes.XMin) / chart3D1.C3DataSeries.XSpacing) + 1;
            chart3D1.C3DataSeries.YNumber = Convert.ToInt16((chart3D1.C3Axes.YMax -
                chart3D1.C3Axes.YMin) / chart3D1.C3DataSeries.YSpacing) + 1;

            Point3[,] pts = new Point3[chart3D1.C3DataSeries.XNumber,
                chart3D1.C3DataSeries.YNumber];
            for (int i = 0; i < chart3D1.C3DataSeries.XNumber; i++)
            {
                for (int j = 0; j < chart3D1.C3DataSeries.YNumber; j++)
                {
                    float x = chart3D1.C3DataSeries.XDataMin +
                        i * chart3D1.C3DataSeries.XSpacing;
                    float y = chart3D1.C3DataSeries.YDataMin +
                        j * chart3D1.C3DataSeries.YSpacing;
                    double zz = 3 * Math.Pow((1 - x), 2) * Math.Exp(-x * x -
                        (y + 1) * (y + 1)) - 10 * (0.2 * x - Math.Pow(x, 3) -
                        Math.Pow(y, 5)) * Math.Exp(-x * x - y * y) -
                        1 / 3 * Math.Exp(-(x + 1) * (x + 1) - y * y);
                    float z = (float)zz;
                    pts[i, j] = new Point3(x, y, z, 1);
                }
            }
            chart3D1.C3DataSeries.PointArray = pts;
        }
    }
}