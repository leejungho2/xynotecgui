using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Chart3DLib;

namespace Example7_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Slice;
            chart3D1.C3DrawChart.XYZSlice = DrawChart.SliceEnum.XSlice;
            chart3D1.C3DrawChart.SliceLocation = 0.5f;
            chart3D1.C3ChartStyle.IsColorBar = true;
            chart3D1.Dock = DockStyle.Fill;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            AddData();
        }

        private void AddData()
        {
            chart3D1.C3Axes.XMin = -2;
            chart3D1.C3Axes.XMax = 2;
            chart3D1.C3Axes.YMin = -2;
            chart3D1.C3Axes.YMax = 2;
            chart3D1.C3Axes.ZMin = -2;
            chart3D1.C3Axes.ZMax = 2;
            chart3D1.C3Axes.XTick = 1;
            chart3D1.C3Axes.YTick = 1;
            chart3D1.C3Axes.ZTick = 1;

            chart3D1.C3DataSeries.XDataMin = chart3D1.C3Axes.XMin;
            chart3D1.C3DataSeries.YDataMin = chart3D1.C3Axes.YMin;
            chart3D1.C3DataSeries.ZZDataMin = chart3D1.C3Axes.ZMin;
            chart3D1.C3DataSeries.XSpacing = 0.2f;
            chart3D1.C3DataSeries.YSpacing = 0.2f;
            chart3D1.C3DataSeries.ZSpacing = 0.2f;
            chart3D1.C3DataSeries.XNumber =
                Convert.ToInt16((chart3D1.C3Axes.XMax - chart3D1.C3Axes.XMin) /
                chart3D1.C3DataSeries.XSpacing) + 1;
            chart3D1.C3DataSeries.YNumber =
                Convert.ToInt16((chart3D1.C3Axes.YMax - chart3D1.C3Axes.YMin) /
                chart3D1.C3DataSeries.YSpacing) + 1;
            chart3D1.C3DataSeries.ZNumber =
                Convert.ToInt16((chart3D1.C3Axes.ZMax - chart3D1.C3Axes.ZMin) /
                chart3D1.C3DataSeries.ZSpacing) + 1;

            Point4[, ,] pts = new Point4[chart3D1.C3DataSeries.XNumber,
                chart3D1.C3DataSeries.YNumber, chart3D1.C3DataSeries.ZNumber];
            for (int i = 0; i < chart3D1.C3DataSeries.XNumber; i++)
            {
                for (int j = 0; j < chart3D1.C3DataSeries.YNumber; j++)
                {
                    for (int k = 0; k < chart3D1.C3DataSeries.ZNumber; k++)
                    {
                        float x = chart3D1.C3DataSeries.XDataMin +
                            i * chart3D1.C3DataSeries.XSpacing;
                        float y = chart3D1.C3DataSeries.YDataMin +
                            j * chart3D1.C3DataSeries.YSpacing;
                        float z = chart3D1.C3Axes.ZMin + k * chart3D1.C3DataSeries.ZSpacing;
                        float v = z * (float)Math.Exp(-x * x - y * y - z * z);
                        pts[i, j, k] = new Point4(new Point3(x, y, z, 1), v);
                    }
                }
            }
            chart3D1.C3DataSeries.Point4Array = pts;
        }
    }
}