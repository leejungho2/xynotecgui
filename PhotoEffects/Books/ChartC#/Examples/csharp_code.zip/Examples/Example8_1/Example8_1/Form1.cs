using System;
using System.Drawing;
using System.Windows.Forms;

namespace Example8_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.White;
            DataGridViewSetup();
            DataGridViewPopulate();
        }

        private void DataGridViewSetup()
        {
            dataGridView1.ColumnCount = 3;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.AutoSizeRowsMode =
                DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            dataGridView1.ColumnHeadersBorderStyle =
                DataGridViewHeaderBorderStyle.Single;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            dataGridView1.GridColor = Color.Black;
            dataGridView1.RowHeadersVisible = true;
            dataGridView1.RowHeadersWidth = 50;
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.RowHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;

            dataGridView1.Columns[0].Name = "X Data";
            dataGridView1.Columns[1].Name = "Y1 Data";
            dataGridView1.Columns[2].Name = "Y2 Data";

            dataGridView1.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
        }

        private void DataGridViewPopulate()
        {
            int nRows = 20;
            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                dataGridView1.Columns[i].Width = 80;
                dataGridView1.Columns[i].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleLeft;
                for (int j = 0; j < nRows; j++)
                {
                    if (i == 0)
                    {
                        dataGridView1.Rows.Add();
                        dataGridView1.Rows[j].HeaderCell.Value = (j + 1).ToString();
                    }

                    float x = (float)Math.Round(j / 3.0, 3);
                    float y1 = (float)Math.Round(Math.Sin(x), 3);
                    float y2 = (float)Math.Round(Math.Cos(x), 3);

                    float value = 0;
                    if (i == 0)
                        value = x;
                    else if (i == 1)
                        value = y1;
                    else if (i == 2)
                        value = y2;

                    dataGridView1[i, j].Value = value.ToString();
                }
            }
        }

        private void btnAddRow_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add();
        }

        private void btnDetaleRow_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0 && 
                dataGridView1.SelectedRows[0].Index !=
                dataGridView1.Rows.Count - 1)
            {
                dataGridView1.Rows.RemoveAt(
                    dataGridView1.SelectedRows[0].Index);
            }
        }
    }
}