namespace Example8_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnReadXML = new System.Windows.Forms.Button();
            this.btnShowSchema = new System.Windows.Forms.Button();
            this.btnReadText = new System.Windows.Forms.Button();
            this.btnShowXML = new System.Windows.Forms.Button();
            this.btnSaveText = new System.Windows.Forms.Button();
            this.btnSaveXML = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(228, 296);
            this.dataGridView1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(192, 296);
            this.textBox1.TabIndex = 1;
            // 
            // btnReadXML
            // 
            this.btnReadXML.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnReadXML.Location = new System.Drawing.Point(8, 336);
            this.btnReadXML.Name = "btnReadXML";
            this.btnReadXML.Size = new System.Drawing.Size(120, 24);
            this.btnReadXML.TabIndex = 2;
            this.btnReadXML.Text = "Read XML";
            this.btnReadXML.UseVisualStyleBackColor = true;
            this.btnReadXML.Click += new System.EventHandler(this.btnReadXML_Click);
            // 
            // btnShowSchema
            // 
            this.btnShowSchema.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnShowSchema.Location = new System.Drawing.Point(152, 336);
            this.btnShowSchema.Name = "btnShowSchema";
            this.btnShowSchema.Size = new System.Drawing.Size(120, 24);
            this.btnShowSchema.TabIndex = 3;
            this.btnShowSchema.Text = "Show XML Schema";
            this.btnShowSchema.UseVisualStyleBackColor = true;
            this.btnShowSchema.Click += new System.EventHandler(this.btnShowSchema_Click);
            // 
            // btnReadText
            // 
            this.btnReadText.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnReadText.Location = new System.Drawing.Point(8, 304);
            this.btnReadText.Name = "btnReadText";
            this.btnReadText.Size = new System.Drawing.Size(120, 24);
            this.btnReadText.TabIndex = 4;
            this.btnReadText.Text = "Read Text";
            this.btnReadText.UseVisualStyleBackColor = true;
            this.btnReadText.Click += new System.EventHandler(this.btnReadText_Click);
            // 
            // btnShowXML
            // 
            this.btnShowXML.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnShowXML.Location = new System.Drawing.Point(152, 304);
            this.btnShowXML.Name = "btnShowXML";
            this.btnShowXML.Size = new System.Drawing.Size(118, 24);
            this.btnShowXML.TabIndex = 5;
            this.btnShowXML.Text = "Show XML";
            this.btnShowXML.UseVisualStyleBackColor = true;
            this.btnShowXML.Click += new System.EventHandler(this.btnShowXML_Click);
            // 
            // btnSaveText
            // 
            this.btnSaveText.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSaveText.Location = new System.Drawing.Point(296, 304);
            this.btnSaveText.Name = "btnSaveText";
            this.btnSaveText.Size = new System.Drawing.Size(118, 24);
            this.btnSaveText.TabIndex = 7;
            this.btnSaveText.Text = "Save Text";
            this.btnSaveText.UseVisualStyleBackColor = true;
            this.btnSaveText.Click += new System.EventHandler(this.btnSaveText_Click);
            // 
            // btnSaveXML
            // 
            this.btnSaveXML.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSaveXML.Location = new System.Drawing.Point(296, 336);
            this.btnSaveXML.Name = "btnSaveXML";
            this.btnSaveXML.Size = new System.Drawing.Size(120, 24);
            this.btnSaveXML.TabIndex = 6;
            this.btnSaveXML.Text = "Save XML";
            this.btnSaveXML.UseVisualStyleBackColor = true;
            this.btnSaveXML.Click += new System.EventHandler(this.btnSaveXML_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.textBox1);
            this.splitContainer1.Size = new System.Drawing.Size(424, 296);
            this.splitContainer1.SplitterDistance = 228;
            this.splitContainer1.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 371);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.btnSaveText);
            this.Controls.Add(this.btnSaveXML);
            this.Controls.Add(this.btnShowXML);
            this.Controls.Add(this.btnReadText);
            this.Controls.Add(this.btnShowSchema);
            this.Controls.Add(this.btnReadXML);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnReadXML;
        private System.Windows.Forms.Button btnShowSchema;
        private System.Windows.Forms.Button btnReadText;
        private System.Windows.Forms.Button btnShowXML;
        private System.Windows.Forms.Button btnSaveText;
        private System.Windows.Forms.Button btnSaveXML;
        private System.Windows.Forms.SplitContainer splitContainer1;
    }
}

