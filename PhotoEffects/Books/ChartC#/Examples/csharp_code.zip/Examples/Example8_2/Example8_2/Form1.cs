using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Example8_2
{
    public partial class Form1 : Form
    {
        private DataSet dataSet1;
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.White;

            dataSet1 = new DataSet();
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.RowHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;
            dataGridView1.RowHeadersWidth = 50;
        }

        private void btnReadXML_Click(object sender, EventArgs e)
        {
            dataSet1 = XML2DataSet.Convert2DataSet();
            dataGridView1.DataSource = dataSet1;
            dataGridView1.DataMember = "MyDataSet";

            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                dataGridView1.Columns[i].Width = 70;
                dataGridView1.Columns[i].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
            }

            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
            }
        }

        private void btnReadText_Click(object sender, EventArgs e)
        {
            dataSet1 = Text2DataSet.Convert2DataSet("MyDataSet");
            dataGridView1.DataSource = dataSet1;
            dataGridView1.DataMember = "MyDataSet";

            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                dataGridView1.Columns[i].Width = 70;
                dataGridView1.Columns[i].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
            }

            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
            }
        }

        private void btnShowSchema_Click(object sender, EventArgs e)
        {
            System.IO.StringWriter swXML = new System.IO.StringWriter();
            dataSet1.WriteXmlSchema(swXML);
            textBox1.Text = swXML.ToString();
        }

        private void btnShowXML_Click(object sender, EventArgs e)
        {
            StringWriter sw = new StringWriter();
            dataSet1.WriteXml(sw);
            textBox1.Text = sw.ToString();
        }

        private void btnSaveText_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 0)
            {
                DataSet2Text.Convert2Text(dataGridView1);
            }
            else
            {
                MessageBox.Show("DataGridView is empty." + 
                    " Please populate it first.");
            }
        }

        private void btnSaveXML_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
            {
                DataSet2XML.Convert2XML(dataSet1);
            }
            else
            {
                MessageBox.Show("There is no Xml file to save." +
                        " Please convert data to Xml file first.");
            }
        }
    }
}