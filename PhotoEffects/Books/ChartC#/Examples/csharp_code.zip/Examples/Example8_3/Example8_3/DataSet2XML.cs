using System;
using System.Text;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace Example8_3
{
    class DataSet2XML
    {
        public static void Convert2XML(DataSet ds)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);
                ds.WriteXml(sw);
            }
        }
    }
}
