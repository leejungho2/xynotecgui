namespace Example8_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Chart2DLib.DataCollection dataCollection1 = new Chart2DLib.DataCollection();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openTextFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openXMLFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTextFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveXMLFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.chart2D1 = new Chart2DLib.Chart2D();
            this.menuStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(464, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openTextFileToolStripMenuItem,
            this.openXMLFileToolStripMenuItem,
            this.saveTextFileToolStripMenuItem,
            this.saveXMLFileToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openTextFileToolStripMenuItem
            // 
            this.openTextFileToolStripMenuItem.Name = "openTextFileToolStripMenuItem";
            this.openTextFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.openTextFileToolStripMenuItem.Text = "Open Text File";
            this.openTextFileToolStripMenuItem.Click += new System.EventHandler(this.openTextFileToolStripMenuItem_Click);
            // 
            // openXMLFileToolStripMenuItem
            // 
            this.openXMLFileToolStripMenuItem.Name = "openXMLFileToolStripMenuItem";
            this.openXMLFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.openXMLFileToolStripMenuItem.Text = "Open XML File";
            this.openXMLFileToolStripMenuItem.Click += new System.EventHandler(this.openXMLFileToolStripMenuItem_Click);
            // 
            // saveTextFileToolStripMenuItem
            // 
            this.saveTextFileToolStripMenuItem.Name = "saveTextFileToolStripMenuItem";
            this.saveTextFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.saveTextFileToolStripMenuItem.Text = "Save Text File";
            this.saveTextFileToolStripMenuItem.Click += new System.EventHandler(this.saveTextFileToolStripMenuItem_Click);
            // 
            // saveXMLFileToolStripMenuItem
            // 
            this.saveXMLFileToolStripMenuItem.Name = "saveXMLFileToolStripMenuItem";
            this.saveXMLFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.saveXMLFileToolStripMenuItem.Text = "Save XML File";
            this.saveXMLFileToolStripMenuItem.Click += new System.EventHandler(this.saveXMLFileToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.chart2D1);
            this.splitContainer1.Size = new System.Drawing.Size(464, 242);
            this.splitContainer1.SplitterDistance = 218;
            this.splitContainer1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(218, 242);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellValueChanged);
            // 
            // chart2D1
            // 
            this.chart2D1.C2ChartArea.ChartBackColor = System.Drawing.SystemColors.Control;
            this.chart2D1.C2ChartArea.ChartBorderColor = System.Drawing.SystemColors.Control;
            this.chart2D1.C2ChartArea.PlotBackColor = System.Drawing.Color.White;
            this.chart2D1.C2ChartArea.PlotBorderColor = System.Drawing.Color.Black;
            dataCollection1.DataSeriesIndex = 0;
            dataCollection1.DataSeriesList = ((System.Collections.ArrayList)(resources.GetObject("dataCollection1.DataSeriesList")));
            this.chart2D1.C2DataCollection = dataCollection1;
            this.chart2D1.C2Grid.GridColor = System.Drawing.Color.LightGray;
            this.chart2D1.C2Grid.GridPattern = System.Drawing.Drawing2D.DashStyle.Solid;
            this.chart2D1.C2Grid.GridThickness = 1F;
            this.chart2D1.C2Grid.IsXGrid = true;
            this.chart2D1.C2Grid.IsYGrid = true;
            this.chart2D1.C2Label.LabelFont = new System.Drawing.Font("Arial", 10F);
            this.chart2D1.C2Label.LabelFontColor = System.Drawing.Color.Black;
            this.chart2D1.C2Label.TickFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chart2D1.C2Label.TickFontColor = System.Drawing.Color.Black;
            this.chart2D1.C2Label.XLabel = "X Axis";
            this.chart2D1.C2Label.Y2Label = "Y2 Axis";
            this.chart2D1.C2Label.YLabel = "Y Axis";
            this.chart2D1.C2Legend.IsBorderVisible = true;
            this.chart2D1.C2Legend.IsLegendVisible = false;
            this.chart2D1.C2Legend.LegendBackColor = System.Drawing.Color.White;
            this.chart2D1.C2Legend.LegendBorderColor = System.Drawing.Color.Black;
            this.chart2D1.C2Legend.LegendFont = new System.Drawing.Font("Arial", 8F);
            this.chart2D1.C2Legend.LegendPosition = Chart2DLib.Legend.LegendPositionEnum.NorthEast;
            this.chart2D1.C2Legend.TextColor = System.Drawing.Color.Black;
            this.chart2D1.C2Title.Title = "Title";
            this.chart2D1.C2Title.TitleFont = new System.Drawing.Font("Arial", 12F);
            this.chart2D1.C2Title.TitleFontColor = System.Drawing.Color.Black;
            this.chart2D1.C2XAxis.XLimMax = 10F;
            this.chart2D1.C2XAxis.XLimMin = 0F;
            this.chart2D1.C2XAxis.XTick = 2F;
            this.chart2D1.C2Y2Axis.IsY2Axis = false;
            this.chart2D1.C2Y2Axis.Y2LimMax = 100F;
            this.chart2D1.C2Y2Axis.Y2LimMin = 0F;
            this.chart2D1.C2Y2Axis.Y2Tick = 20F;
            this.chart2D1.C2YAxis.YLimMax = 10F;
            this.chart2D1.C2YAxis.YLimMin = 0F;
            this.chart2D1.C2YAxis.YTick = 2F;
            this.chart2D1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart2D1.Location = new System.Drawing.Point(0, 0);
            this.chart2D1.Name = "chart2D1";
            this.chart2D1.Size = new System.Drawing.Size(242, 242);
            this.chart2D1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 266);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openTextFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openXMLFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveTextFileToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Chart2DLib.Chart2D chart2D1;
        private System.Windows.Forms.ToolStripMenuItem saveXMLFileToolStripMenuItem;
    }
}

