using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Chart2DLib;

namespace Example8_3
{
    public partial class Form1 : Form
    {
        private DataSeries ds;
        private DataSet dataSet1;

        public Form1()
        {
            InitializeComponent();
            ds = new DataSeries();
            dataSet1 = new DataSet();
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.RowHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;
            dataGridView1.RowHeadersWidth = 50;

            // Override ChartStyle properties:
            chart2D1.C2ChartArea.ChartBackColor = Color.White;
            chart2D1.C2XAxis.XLimMin = 0f;
            chart2D1.C2XAxis.XLimMax = 7f;
            chart2D1.C2YAxis.YLimMin = -1.5f;
            chart2D1.C2YAxis.YLimMax = 1.5f;
            chart2D1.C2XAxis.XTick = 1.0f;
            chart2D1.C2YAxis.YTick = 0.5f;
            chart2D1.C2Label.XLabel = "This is X axis";
            chart2D1.C2Label.YLabel = "This is Y axis";
            chart2D1.C2Title.Title = "Sine and Cosine Chart";
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (dataGridView1.RowCount > 0)
            {
                AddData();
            }
        }
        private void AddData()
        {
            chart2D1.C2DataCollection.DataSeriesList.Clear();
            // Add first data series:
            ds = new DataSeries();
            ds.LineStyle.LineColor = Color.Red;
            ds.LineStyle.Thickness = 2f;
            ds.LineStyle.Pattern = DashStyle.Dash;
            ds.LineStyle.PlotMethod =
                LineStyle.PlotLinesMethodEnum.Lines;
            ds.SeriesName = "Sine";
            ds.SymbolStyle.SymbolType =
                SymbolStyle.SymbolTypeEnum.Diamond;
            ds.SymbolStyle.BorderColor = Color.Red;
            ds.SymbolStyle.FillColor = Color.Yellow;
            ds.SymbolStyle.BorderThickness = 1f;
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                string value1 = dataGridView1[0, i].Value as string;
                string value2 = dataGridView1[1, i].Value as string;
                if (value1 != null && value2 != null)
                {

                    float x = Convert.ToSingle((string)dataGridView1[0, i].Value);
                    float y = Convert.ToSingle((string)dataGridView1[1, i].Value);
                    ds.AddPoint(new PointF(x, y));
                }
            }
            chart2D1.C2DataCollection.Add(ds);

            // Add second data series:
            ds = new DataSeries();
            ds.LineStyle.LineColor = Color.Blue;
            ds.LineStyle.Thickness = 1f;
            ds.LineStyle.Pattern = DashStyle.Solid;
            ds.LineStyle.PlotMethod =
                LineStyle.PlotLinesMethodEnum.Splines;
            ds.SeriesName = "Cosine";
            ds.SymbolStyle.SymbolType =
                SymbolStyle.SymbolTypeEnum.Triangle;
            ds.SymbolStyle.BorderColor = Color.Blue;
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                string value1 = dataGridView1[0, i].Value as string;
                string value2 = dataGridView1[2, i].Value as string;
                if (value1 != null && value2 != null)
                {

                    float x = Convert.ToSingle((string)dataGridView1[0, i].Value);
                    float y = Convert.ToSingle((string)dataGridView1[2, i].Value);
                    ds.AddPoint(new PointF(x, y));
                }
            }
            chart2D1.C2DataCollection.Add(ds);
        }


        private void openTextFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataSet1 = Text2DataSet.Convert2DataSet("MyDataSet");
            dataGridView1.DataSource = dataSet1;
            dataGridView1.DataMember = "MyDataSet";

            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                dataGridView1.Columns[i].Width = 70;
                dataGridView1.Columns[i].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
            }

            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
            }
        }

        private void openXMLFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataSet1 = XML2DataSet.Convert2DataSet();
            dataGridView1.DataSource = dataSet1;
            dataGridView1.DataMember = "MyDataSet";

            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                dataGridView1.Columns[i].Width = 70;
                dataGridView1.Columns[i].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
            }

            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
            }
        }

        private void saveTextFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 0)
            {
                DataSet2Text.Convert2Text(dataGridView1);
            }
        }

        private void saveXMLFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 0)
            {
                DataSet2XML.Convert2XML(dataSet1);
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            this.Invalidate();
        }
    }
}