using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using Chart2DLib;

namespace Example8_4
{
    public class ChartStyle
    {
        private Color chartBackColor = Color.White;
        private Color plotBackColor = Color.White;
        private bool isLegendVisible = false;
        private float xLimMin = 0f;
        private float xLimMax = 10f;
        private float xTick = 2f;
        private float yLimMin = 0f;
        private float yLimMax = 10f;
        private float yTick = 2f;
        private DashStyle gridPattern = DashStyle.Solid;
        private Color gridColor = Color.LightGray;
        private float gridLineThickness = 1.0f;
        private bool isXGrid = true;
        private bool isYGrid = true;
        private string xLabel = "X Axis";
        private string yLabel = "Y Axis";
        private string title = "My 2D Chart";

        public ChartStyle()
        {
        }

        [Description("The background color of the chart area."),
        Category("Chart Style")]
        public Color ChartBackColor
        {
            get { return chartBackColor; }
            set { chartBackColor = value; }
        }

        [Description("The background color of the plot area."),
        Category("Chart Style")]
        public Color PlotBackColor
        {
            get { return plotBackColor; }
            set { plotBackColor = value; }
        }

        [Description("Indicates whether the legend should be shown."),
        Category("Chart Style"), DefaultValue(false)]
        public bool IsLegendVisible
        {
            get { return isLegendVisible; }
            set { isLegendVisible = value; }
        }

        [Description("Sets the maximum limit for the X axis."),
         Category("Axes"), DefaultValue(10)]
        public float XLimMax
        {
            get { return xLimMax; }
            set { xLimMax = value; }
        }

        [Description("Sets the maximum limit for the X axis."),
        Category("Axes"), DefaultValue(0)]
        public float XLimMin
        {
            get { return xLimMin; }
            set { xLimMin = value; }
        }

        [Description("Sets the ticks for the X axis."),
        Category("Axes"), DefaultValue(2)]
        public float XTick
        {
            get { return xTick; }
            set { xTick = value; }
        }

        [Description("Sets the maximum limit for the Y axis."),
         Category("Axes"), DefaultValue(10)]
        public float YLimMax
        {
            get { return yLimMax; }
            set { yLimMax = value; }
        }

        [Description("Sets the maximum limit for the Y axis."),
        Category("Axes"), DefaultValue(0)]
        public float YLimMin
        {
            get { return yLimMin; }
            set { yLimMin = value; }
        }

        [Description("Sets the ticks for the X axis."),
        Category("Axes"), DefaultValue(2)]
        public float YTick
        {
            get { return yTick; }
            set { yTick = value; }
        }

        [Description("Indicates whether the X grid is shown."),
        Category("Grid"), DefaultValue(true)]
        public bool IsXGrid
        {
            get { return isXGrid; }
            set { isXGrid = value; }
        }

        [Description("Indicates whether the Y grid is shown."),
        Category("Grid"), DefaultValue(true)]
        public bool IsYGrid
        {
            get { return isYGrid; }
            set { isYGrid = value; }
        }

        [Description("Sets the line pattern for the grid lines."),
        Category("Grid")]
        virtual public DashStyle GridPattern
        {
            get { return gridPattern; }
            set { gridPattern = value; }
        }

        [Description("Sets the thickness for the grid lines."),
        Category("Grid"), DefaultValue(1)]
        public float GridThickness
        {
            get { return gridLineThickness; }
            set { gridLineThickness = value; }
        }

        [Description("The color used to display the grid lines."),
        Category("Grid")]
        virtual public Color GridColor
        {
            get { return gridColor; }
            set { gridColor = value; }
        }

        [Description("Creates a label for the X axis."),
        Category("Title and Labels"), DefaultValue("X Axis")]
        public string XLabel
        {
            get { return xLabel; }
            set { xLabel = value; }
        }

        [Description("Creates a label for the Y axis."),
        Category("Title and Labels"), DefaultValue("Y Axis")]
        public string YLabel
        {
            get { return yLabel; }
            set { yLabel = value; }
        }

        [Description("Creates a title for the chart."),
        Category("Title and Labels"), DefaultValue("My 2D Chart")]
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
    }
}
