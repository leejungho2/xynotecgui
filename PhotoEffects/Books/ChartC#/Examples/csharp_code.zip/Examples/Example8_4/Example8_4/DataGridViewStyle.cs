using System;
using System.ComponentModel;
using System.Drawing;

namespace Example8_4
{
    public class DataGridViewStyle
    {
        private Color firstColumnColor = Color.White;
        private Color secondColumnColor = Color.White;
        private Color thirdColumnColor = Color.White;


        [Description("Sets the background color of the first column."),
        Category("Background Color")]
        public Color FirstColumnColor
        {
            get { return firstColumnColor; }
            set { firstColumnColor = value; }
        }

        [Description("Sets the background color of the second column."),
        Category("Background Color")]
        public Color SecondColumnColor
        {
            get { return secondColumnColor; }
            set { secondColumnColor = value; }
        }

        [Description("Sets the background color of the third column."),
        Category("Background Color")]
        public Color ThirdColumnColor
        {
            get { return thirdColumnColor; }
            set { thirdColumnColor = value; }
        }
    }
}
