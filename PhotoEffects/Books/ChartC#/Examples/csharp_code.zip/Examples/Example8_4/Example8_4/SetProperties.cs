using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Example8_4
{
    public partial class SetProperties : Form
    {
        private Form1 form1;
        private ChartStyle cs;
        private DataGridViewStyle dgvs;
        private string sProperty;

        public SetProperties(Form1 fm1, ChartStyle chartStyle, string sproperty)
        {
            InitializeComponent();
            form1 = fm1;
            sProperty = sproperty;
            cs = chartStyle;
            cs.ChartBackColor = form1.BackColor;
            propertyGrid1.SelectedObject = cs;
        }

        public SetProperties(Form1 fm1, DataGridViewStyle dataGridViewStyle, string sproperty)
        {
            InitializeComponent();
            form1 = fm1;
            sProperty = sproperty;
            dgvs = dataGridViewStyle;
            propertyGrid1.SelectedObject = dgvs;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (sProperty == "ChartStyle")
            {
                Chart2DSettings();
            }
            else if (sProperty == "DataGridViewStyle")
            {
                DataGridViewSettings();
            }
        }

        private void Chart2DSettings()
        {
            form1.chart2D1.C2Legend.IsLegendVisible = cs.IsLegendVisible;
            form1.chart2D1.C2ChartArea.ChartBackColor = cs.ChartBackColor;
            form1.chart2D1.C2ChartArea.PlotBackColor = cs.PlotBackColor;
            form1.chart2D1.C2XAxis.XLimMax = cs.XLimMax;
            form1.chart2D1.C2XAxis.XLimMin = cs.XLimMin;
            form1.chart2D1.C2XAxis.XTick = cs.XTick;
            form1.chart2D1.C2YAxis.YLimMax = cs.YLimMax;
            form1.chart2D1.C2YAxis.YLimMin = cs.YLimMin;
            form1.chart2D1.C2YAxis.YTick = cs.YTick;
            form1.chart2D1.C2Grid.GridColor = cs.GridColor;
            form1.chart2D1.C2Grid.GridPattern = cs.GridPattern;
            form1.chart2D1.C2Grid.GridThickness = cs.GridThickness;
            form1.chart2D1.C2Grid.IsXGrid = cs.IsXGrid;
            form1.chart2D1.C2Grid.IsYGrid = cs.IsYGrid;
            form1.chart2D1.C2Title.Title = cs.Title;
            form1.chart2D1.C2Label.XLabel = cs.XLabel;
            form1.chart2D1.C2Label.YLabel = cs.YLabel;
        }

        private void DataGridViewSettings()
        {
            if (form1.dataGridView1.ColumnCount > 2)
            {
                form1.dataGridView1.Columns[0].DefaultCellStyle.BackColor = 
                    dgvs.FirstColumnColor;
                form1.dataGridView1.Columns[1].DefaultCellStyle.BackColor =
                    dgvs.SecondColumnColor;
                form1.dataGridView1.Columns[2].DefaultCellStyle.BackColor =
                    dgvs.ThirdColumnColor;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       
    }
}