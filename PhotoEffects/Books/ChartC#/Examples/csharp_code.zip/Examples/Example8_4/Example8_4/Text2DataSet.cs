using System;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace Example8_4
{
    public class Text2DataSet
    {
        public static DataSet Convert2DataSet(string tableName)
        {
            DataSet ds = new DataSet();
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(openFileDialog1.FileName);
                char[] cSplitter = { ' ', ',', ':', '\t' };
                // Split the first line into the columns       
                string[] columns = sr.ReadLine().Split(cSplitter);
                ds.Tables.Add(tableName);

                foreach (string col in columns)
                {
                    ds.Tables[tableName].Columns.Add(col);
                }

                //Read the rest of the data in the file.        
                string TotalData = sr.ReadToEnd();
                string[] rows = TotalData.Split("\r".ToCharArray());

                // Add data the DataSet        
                foreach (string row in rows)
                {
                     string[] items = row.Split(cSplitter);
                    ds.Tables[tableName].Rows.Add(items);
                }
            }
            return ds;
        }
    }
}
