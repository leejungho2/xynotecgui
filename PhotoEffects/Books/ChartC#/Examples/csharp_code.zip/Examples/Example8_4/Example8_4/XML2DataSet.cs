using System;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace Example8_4
{
    class XML2DataSet
    {
        public static DataSet Convert2DataSet()
        {
            DataSet ds = new DataSet();
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ds.ReadXml(openFileDialog1.FileName);
            }
            return ds;
        }
    }
}
