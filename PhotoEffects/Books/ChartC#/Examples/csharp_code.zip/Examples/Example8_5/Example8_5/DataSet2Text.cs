using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections.Specialized;
using System.Collections;
using System.Windows.Forms;

namespace Example8_5
{
    class DataSet2Text
    {
        public static void Convert2Text(DataGridView dgv)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter sr = new StreamWriter(saveFileDialog1.FileName);
                    string textLine;
                    for (int j = 0; j < dgv.RowCount - 1; j++)
                    {
                        string value = dgv[0, j].Value as string;
                        if (value != null)
                        {
                            textLine = dgv[0, j].Value.ToString();
                            for (int i = 1; i < dgv.ColumnCount; i++)
                            {
                                string value1 = dgv[i, j].Value as string;
                                if (value1 != null)
                                {
                                    textLine = textLine + "\t" + dgv[i, j].Value.ToString();
                                }
                            }
                            sr.WriteLine(textLine);
                        }
                    }
                    sr.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message, "Error saving file.");
                }
            }
        }
    }
}
