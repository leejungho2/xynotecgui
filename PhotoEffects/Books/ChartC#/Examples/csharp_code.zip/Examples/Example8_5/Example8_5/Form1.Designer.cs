namespace Example8_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Chart3DLib.LineStyle lineStyle7 = new Chart3DLib.LineStyle();
            Chart3DLib.DataSeries dataSeries3 = new Chart3DLib.DataSeries();
            Chart3DLib.BarStyle barStyle3 = new Chart3DLib.BarStyle();
            Chart3DLib.LineStyle lineStyle8 = new Chart3DLib.LineStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Chart3DLib.LineStyle lineStyle9 = new Chart3DLib.LineStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openTextFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openXMLFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTextFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveXMLFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propertySettingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chartStyleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.axesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.chart3D1 = new Chart3DLib.Chart3D();
            this.menuStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.propertySettingToolStripMenuItem,
            this.toolStripComboBox1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(449, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openTextFileToolStripMenuItem,
            this.openXMLFileToolStripMenuItem,
            this.saveTextFileToolStripMenuItem,
            this.saveXMLFileToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 21);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openTextFileToolStripMenuItem
            // 
            this.openTextFileToolStripMenuItem.Name = "openTextFileToolStripMenuItem";
            this.openTextFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.openTextFileToolStripMenuItem.Text = "Open Text File";
            // 
            // openXMLFileToolStripMenuItem
            // 
            this.openXMLFileToolStripMenuItem.Name = "openXMLFileToolStripMenuItem";
            this.openXMLFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.openXMLFileToolStripMenuItem.Text = "Open XML File";
            // 
            // saveTextFileToolStripMenuItem
            // 
            this.saveTextFileToolStripMenuItem.Name = "saveTextFileToolStripMenuItem";
            this.saveTextFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.saveTextFileToolStripMenuItem.Text = "Save Text File";
            this.saveTextFileToolStripMenuItem.Click += new System.EventHandler(this.saveTextFileToolStripMenuItem_Click);
            // 
            // saveXMLFileToolStripMenuItem
            // 
            this.saveXMLFileToolStripMenuItem.Name = "saveXMLFileToolStripMenuItem";
            this.saveXMLFileToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.saveXMLFileToolStripMenuItem.Text = "Save XML File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // propertySettingToolStripMenuItem
            // 
            this.propertySettingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chartStyleToolStripMenuItem,
            this.axesToolStripMenuItem,
            this.gridToolStripMenuItem});
            this.propertySettingToolStripMenuItem.Name = "propertySettingToolStripMenuItem";
            this.propertySettingToolStripMenuItem.Size = new System.Drawing.Size(98, 21);
            this.propertySettingToolStripMenuItem.Text = "Property Setting";
            // 
            // chartStyleToolStripMenuItem
            // 
            this.chartStyleToolStripMenuItem.Name = "chartStyleToolStripMenuItem";
            this.chartStyleToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.chartStyleToolStripMenuItem.Text = "Chart Style";
            // 
            // axesToolStripMenuItem
            // 
            this.axesToolStripMenuItem.Name = "axesToolStripMenuItem";
            this.axesToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.axesToolStripMenuItem.Text = "Axes ";
            // 
            // gridToolStripMenuItem
            // 
            this.gridToolStripMenuItem.Name = "gridToolStripMenuItem";
            this.gridToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.gridToolStripMenuItem.Text = "Grid";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(170, 21);
            this.toolStripComboBox1.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.chart3D1);
            this.splitContainer1.Size = new System.Drawing.Size(449, 241);
            this.splitContainer1.SplitterDistance = 206;
            this.splitContainer1.TabIndex = 1;
            this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(206, 241);
            this.dataGridView1.TabIndex = 0;
            // 
            // chart3D1
            // 
            this.chart3D1.BackColor = System.Drawing.Color.White;
            lineStyle7.IsVisible = true;
            lineStyle7.LineColor = System.Drawing.Color.Black;
            lineStyle7.Pattern = System.Drawing.Drawing2D.DashStyle.Solid;
            lineStyle7.PlotMethod = Chart3DLib.LineStyle.PlotLinesMethodEnum.Lines;
            lineStyle7.Thickness = 1F;
            this.chart3D1.C3Axes.AxisStyle = lineStyle7;
            this.chart3D1.C3Axes.XMax = 5F;
            this.chart3D1.C3Axes.XMin = -5F;
            this.chart3D1.C3Axes.XTick = 1F;
            this.chart3D1.C3Axes.YMax = 3F;
            this.chart3D1.C3Axes.YMin = -3F;
            this.chart3D1.C3Axes.YTick = 1F;
            this.chart3D1.C3Axes.ZMax = 6F;
            this.chart3D1.C3Axes.ZMin = -6F;
            this.chart3D1.C3Axes.ZTick = 3F;
            barStyle3.IsBarSingleColor = false;
            barStyle3.XLength = 0.5F;
            barStyle3.YLength = 0.5F;
            barStyle3.ZOrigin = 0F;
            dataSeries3.BarStyle = barStyle3;
            lineStyle8.IsVisible = true;
            lineStyle8.LineColor = System.Drawing.Color.Black;
            lineStyle8.Pattern = System.Drawing.Drawing2D.DashStyle.Solid;
            lineStyle8.PlotMethod = Chart3DLib.LineStyle.PlotLinesMethodEnum.Lines;
            lineStyle8.Thickness = 1F;
            dataSeries3.LineStyle = lineStyle8;
            dataSeries3.Point4Array = null;
            dataSeries3.PointArray = null;
            dataSeries3.PointList = ((System.Collections.ArrayList)(resources.GetObject("dataSeries3.PointList")));
            dataSeries3.XDataMin = -5F;
            dataSeries3.XNumber = 10;
            dataSeries3.XSpacing = 1F;
            dataSeries3.YDataMin = -5F;
            dataSeries3.YNumber = 10;
            dataSeries3.YSpacing = 1F;
            dataSeries3.ZNumber = 10;
            dataSeries3.ZSpacing = 1F;
            dataSeries3.ZZDataMin = -5F;
            this.chart3D1.C3DataSeries = dataSeries3;
            lineStyle9.IsVisible = true;
            lineStyle9.LineColor = System.Drawing.Color.LightGray;
            lineStyle9.Pattern = System.Drawing.Drawing2D.DashStyle.Solid;
            lineStyle9.PlotMethod = Chart3DLib.LineStyle.PlotLinesMethodEnum.Lines;
            lineStyle9.Thickness = 1F;
            this.chart3D1.C3Grid.GridStyle = lineStyle9;
            this.chart3D1.C3Grid.IsXGrid = true;
            this.chart3D1.C3Grid.IsYGrid = true;
            this.chart3D1.C3Grid.IsZGrid = true;
            this.chart3D1.C3Labels.LabelFont = new System.Drawing.Font("Arial", 10F);
            this.chart3D1.C3Labels.LabelFontColor = System.Drawing.Color.Black;
            this.chart3D1.C3Labels.TickFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chart3D1.C3Labels.TickFontColor = System.Drawing.Color.Black;
            this.chart3D1.C3Labels.Title = "My 3D Chart";
            this.chart3D1.C3Labels.TitleColor = System.Drawing.Color.Black;
            this.chart3D1.C3Labels.TitleFont = new System.Drawing.Font("Arial Narrow", 14F);
            this.chart3D1.C3Labels.XLabel = "X Axis";
            this.chart3D1.C3Labels.YLabel = "Y Axis";
            this.chart3D1.C3Labels.ZLabel = "Z Axis";
            this.chart3D1.C3ViewAngle.Azimuth = -37.5F;
            this.chart3D1.C3ViewAngle.Elevation = 30F;
            this.chart3D1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart3D1.Location = new System.Drawing.Point(0, 0);
            this.chart3D1.Name = "chart3D1";
            this.chart3D1.Size = new System.Drawing.Size(239, 241);
            this.chart3D1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 266);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openTextFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openXMLFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveTextFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveXMLFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propertySettingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chartStyleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem axesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gridToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private Chart3DLib.Chart3D chart3D1;
    }
}

