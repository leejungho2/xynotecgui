using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Data;
using System.Windows.Forms;
using Chart3DLib;

namespace Example8_5
{
    public partial class Form1 : Form
    {
        private DataSeries ds;
        private DataSet dataSet1;

        public Form1()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            ComboboxSetup();
            ds = new DataSeries();
            dataSet1 = new DataSet();
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.RowHeadersDefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;
            dataGridView1.RowHeadersWidth = 70;
        }

        private void ComboboxSetup()
        {
            toolStripComboBox1.Items.Add("Mesh");
            toolStripComboBox1.Items.Add("MeshZ");
            toolStripComboBox1.Items.Add("Waterfall");
            toolStripComboBox1.Items.Add("Surface");
            toolStripComboBox1.Items.Add("XYColor");
            toolStripComboBox1.Items.Add("Contour");
            toolStripComboBox1.Items.Add("Filled Contour");
            toolStripComboBox1.Items.Add("Mesh + Contour");
            toolStripComboBox1.Items.Add("Surface + Contour");
            toolStripComboBox1.Items.Add("Surface + Contour");
            toolStripComboBox1.Items.Add("Surface + Filled Contour");
            toolStripComboBox1.Items.Add("Bar3D");
            toolStripComboBox1.SelectedItem = "Surface";
        }

        private void ChartTypeSetup()
        {
            string chartType = toolStripComboBox1.SelectedItem.ToString();
            switch (chartType)
            {
                case "Mesh":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Mesh;
                    break;
                case "MeshZ":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.MeshZ;
                    break;
                case "Waterfall":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Waterfall;
                    break;
                case "Surface":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Surface;
                    break;
                case "XYColor":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.XYColor;
                    break;
                case "Contour":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Contour;
                    break;
                case "Filled Contour":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.FillContour;
                    break;
                case "Mesh + Contour":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.MeshContour;
                    break;
                case "Surface + Contour":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.SurfaceContour;
                    break;
                case "Surface + Filled Contour":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.SurfaceFillContour;
                    break;
                case "Bar3D":
                    chart3D1.C3DrawChart.ChartType = DrawChart.ChartTypeEnum.Bar3D;
                    break;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            AddData();
            if (dataGridView1.RowCount == 0)
            {
                PopulateDadaGridView();
            }
            if (dataGridView1.RowCount > 0)
            {
                ChartTypeSetup();
            }
        }

        private void PopulateDadaGridView()
        {
            Point3[,] zdata = chart3D1.C3DataSeries.PointArray;
            int nx = zdata.GetLength(0);
            int ny = zdata.GetLength(1);
            float[] xdata = new float[nx];
            float[] ydata = new float[ny];
            for (int i = 0; i < nx; i++)
            {
                xdata[i] = chart3D1.C3DataSeries.XDataMin +
                    i * chart3D1.C3DataSeries.XSpacing;
            }
            for (int j = 0; j < ny; j++)
            {
                ydata[j] = chart3D1.C3DataSeries.YDataMin +
                    j * chart3D1.C3DataSeries.YSpacing;
            }
            dataGridView1.ColumnCount = nx + 1;
            for (int i = 0; i < dataGridView1.ColumnCount; i++)
            {
                dataGridView1.RowHeadersDefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;
                dataGridView1.Columns[i].Width = 80;
                dataGridView1.Columns[i].DefaultCellStyle.Alignment =
                    DataGridViewContentAlignment.MiddleRight;

                for (int j = 0; j < ny + 1; j++)
                {
                    if (i == 0)
                    {
                        dataGridView1.Rows.Add();
                        dataGridView1[0, 0].Value = "NA";
                        if (j > 0)
                        {
                            dataGridView1.Rows[j].HeaderCell.Value = "Y" + j.ToString();
                            dataGridView1[0, j].Value = ydata[j - 1].ToString();
                        }
                    }
                    if (i > 0)
                    {
                        dataGridView1.Columns[i].Name = "X" + i.ToString();
                        dataGridView1[i, 0].Value = xdata[i - 1].ToString();
                    }

                    if (i > 0 && j > 0)
                    {
                        dataGridView1[i, j].Value = zdata[i - 1, j - 1].Z.ToString();
                    }
                }
            }
        }

        private void AddData()
        {
            chart3D1.C3Axes.XMin = -3;
            chart3D1.C3Axes.XMax = 3;
            chart3D1.C3Axes.YMin = -3;
            chart3D1.C3Axes.YMax = 3;
            chart3D1.C3Axes.ZMin = -8;
            chart3D1.C3Axes.ZMax = 8;
            chart3D1.C3Axes.XTick = 1;
            chart3D1.C3Axes.YTick = 1;
            chart3D1.C3Axes.ZTick = 4;

            chart3D1.C3DataSeries.XDataMin = chart3D1.C3Axes.XMin;
            chart3D1.C3DataSeries.YDataMin = chart3D1.C3Axes.YMin;
            chart3D1.C3DataSeries.XSpacing = 0.3f;
            chart3D1.C3DataSeries.YSpacing = 0.3f;
            chart3D1.C3DataSeries.XNumber = Convert.ToInt16(
			  (chart3D1.C3Axes.XMax - chart3D1.C3Axes.XMin) /
 			  chart3D1.C3DataSeries.XSpacing) + 1;
            chart3D1.C3DataSeries.YNumber = Convert.ToInt16(
			  (chart3D1.C3Axes.YMax - chart3D1.C3Axes.YMin) / 
			  chart3D1.C3DataSeries.YSpacing) + 1;

            Point3[,] pts = new Point3[chart3D1.C3DataSeries.XNumber,
                chart3D1.C3DataSeries.YNumber];
            for (int i = 0; i < chart3D1.C3DataSeries.XNumber; i++)
            {
                for (int j = 0; j < chart3D1.C3DataSeries.YNumber; 
					j++)
                {
                    float x = chart3D1.C3DataSeries.XDataMin +
                        i * chart3D1.C3DataSeries.XSpacing;
                    float y = chart3D1.C3DataSeries.YDataMin +
                        j * chart3D1.C3DataSeries.YSpacing;
                    double zz = 3 * Math.Pow((1 - x), 2) * 
					Math.Exp(-x * x - (y + 1) * (y + 1)) - 10 * 
					(0.2 * x - Math.Pow(x, 3) - Math.Pow(y, 5)) * 
					Math.Exp(-x * x - y * y) - 1 / 3 * 
					Math.Exp(-(x + 1) * (x + 1) - y * y);
                    float z = (float)zz;
                    pts[i, j] = new Point3(x, y, z, 1);
                }
            }
            chart3D1.C3DataSeries.PointArray = pts;
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        private void saveTextFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 0)
            {
                DataSet2Text.Convert2Text(dataGridView1);
            }
        }

        private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
        {
            this.Invalidate();
        }

    }
}