using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace VectorChart
{
    public partial class Form1 : Form
    {
        private DataCollection dc;
        private ChartStyle cs;

        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.ResizeRedraw, true);
            this.BackColor = Color.White;

            //set Form1 size:
            this.Width = 350;
            this.Height = 350;
            dc = new DataCollection();
            cs = new ChartStyle(this);
            cs.XLimMin = -8f;
            cs.XLimMax = 8f;
            cs.YLimMin = -8f;
            cs.YLimMax = 8f;
            cs.IsXGrid = false;
            cs.IsYGrid = false;
            cs.XTick = 4f;
            cs.YTick = 4f;
            cs.Title = "Vector Chart";
        }

        private void AddData(Graphics g)
        {
            dc.DataSeriesList.Clear();

            for (int i = 1; i < 16; i++)
            {
                for (int j = 1; j < 16; j++)
                {
                    double x = i - 8;
                    double y = j - 8;
                    double a = 4;
                    float ex = (float)((x - a) / Math.Pow((x - a) * (x - a) + y * y, 0.8) -
                                (x + a) / Math.Pow((x + a) * (x + a) + y * y, 0.8));
                    float ey = (float)(y / Math.Pow((x - a) * (x - a) + y * y, 0.8) -
                                y / Math.Pow((x + a) * (x + a) + y * y, 0.8));
                    float em = (float)Math.Sqrt(ex * ex + ey * ey);

                    dc.AddVectorChart(g, cs, 0.7f*em, new PointF((float)x, (float)y), ex, ey);
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            cs.ChartArea = this.ClientRectangle;
            SetPlotArea(g);
            cs.AddChartStyle(g);
            AddData(g);
            g.Dispose();
        }

        private void SetPlotArea(Graphics g)
        {
            // Set PlotArea:
            float xOffset = cs.ChartArea.Width / 30.0f;
            float yOffset = cs.ChartArea.Height / 30.0f;
            SizeF labelFontSize = g.MeasureString("A", cs.LabelFont);
            SizeF titleFontSize = g.MeasureString("A", cs.TitleFont);
            if (cs.Title.ToUpper() == "NO TITLE")
            {
                titleFontSize.Width = 8f;
                titleFontSize.Height = 8f;
            }
            float xSpacing = xOffset / 3.0f;
            float ySpacing = yOffset / 3.0f;
            SizeF tickFontSize = g.MeasureString("A", cs.TickFont);
            float tickSpacing = 2f;
            SizeF yTickSize = g.MeasureString(cs.YLimMin.ToString(), cs.TickFont);
            for (float yTick = cs.YLimMin; yTick <= cs.YLimMax; yTick += cs.YTick)
            {
                SizeF tempSize = g.MeasureString(yTick.ToString(), cs.TickFont);
                if (yTickSize.Width < tempSize.Width)
                {
                    yTickSize = tempSize;
                }
            }
            float leftMargin = xOffset + labelFontSize.Width +
                        xSpacing + yTickSize.Width + tickSpacing;
            float rightMargin = 2 * xOffset;
            float topMargin = yOffset + titleFontSize.Height + ySpacing;
            float bottomMargin = yOffset + labelFontSize.Height +
                        ySpacing + tickSpacing + tickFontSize.Height;

            // Define the plot area with one Y axis:
            int plotX = cs.ChartArea.X + (int)leftMargin;
            int plotY = cs.ChartArea.Y + (int)topMargin;
            int plotWidth = cs.ChartArea.Width - (int)leftMargin - (int)rightMargin;
            int plotHeight = cs.ChartArea.Height - (int)topMargin - (int)bottomMargin;
            cs.PlotArea = new Rectangle(plotX, plotY, plotWidth, plotHeight);
        }
    }
}